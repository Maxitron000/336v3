
import logging
import os
import asyncio
import signal
import sys
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from keep_alive import keep_alive
from config import BOT_TOKEN
from handlers import register_user_handlers, register_admin_handlers
from services.db_service import init_db
from services.scheduler import init_scheduler, stop_scheduler
from utils.console_logger import startup_sequence, log_status
from bot_manager import BotManager

# Настройки логирования (скрываем стандартные логи aiogram)
logging.basicConfig(level=logging.WARNING)

# Глобальные переменные для graceful shutdown
bot = None
dp = None
keep_alive_server = None
bot_manager = None

def signal_handler(signum, frame):
    """Обработчик сигналов для graceful shutdown"""
    log_status("Получен сигнал завершения, останавливаем бот...", "WARNING")
    
    # Создаем задачу для graceful shutdown
    async def async_shutdown():
        await shutdown()
    
    # Запускаем shutdown в event loop если он доступен
    try:
        import asyncio
        loop = asyncio.get_running_loop()
        loop.create_task(async_shutdown())
    except RuntimeError:
        # Если event loop недоступен, делаем синхронную очистку
        if bot_manager:
            bot_manager.cleanup()
        sys.exit(0)

async def shutdown():
    """Корректное завершение работы бота"""
    # Останавливаем планировщик
    await stop_scheduler()
    
    if bot:
        await bot.close()
    if bot_manager:
        bot_manager.cleanup()
    log_status("Бот корректно остановлен", "SUCCESS")

async def main():
    global bot, dp, keep_alive_server, bot_manager
    
    # Красивый вывод запуска
    startup_sequence()
    
    # Инициализируем менеджер бота
    bot_manager = BotManager()
    
    # Проверяем и останавливаем существующие экземпляры
    if not bot_manager.ensure_single_instance():
        log_status("Не удалось обеспечить единственный экземпляр бота", "ERROR")
        return
    
    # Включаем Flask-сервер для 24/7 работы на Replit
    try:
        keep_alive_server = keep_alive()
        log_status("Keep-alive сервер запущен успешно", "SUCCESS")
    except Exception as e:
        log_status(f"Ошибка запуска keep-alive сервера: {e}", "WARNING")
        log_status("Продолжаем работу без keep-alive...", "INFO")

    # Бот, хранилище состояний
    bot = Bot(token=BOT_TOKEN, parse_mode=types.ParseMode.HTML)
    storage = MemoryStorage()
    dp = Dispatcher(bot, storage=storage)

    # Инициализируем базу данных
    log_status("Инициализация базы данных...")
    init_db()
    log_status("База данных инициализирована успешно ✅", "SUCCESS")

    # Регистрируем все хендлеры
    log_status("Регистрация обработчиков...")
    register_user_handlers(dp)
    register_admin_handlers(dp)
    log_status("Обработчики зарегистрированы ✅", "SUCCESS")

    # Запускаем планировщик автозадач
    log_status("Запуск планировщика автозадач...")
    await init_scheduler(bot)
    log_status("Планировщик запущен ✅", "SUCCESS")

    # Регистрируем обработчики сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        log_status("Запуск polling режима...", "INFO")
        log_status("🎖️ ARMY BOT ГОТОВ К СЛУЖБЕ! 🎖️", "SUCCESS")
        
        # Пробуем запустить polling с обработкой ошибок
        retry_count = 0
        max_retries = 3
        
        while retry_count < max_retries:
            try:
                await dp.start_polling()
                break  # Если успешно запустились, выходим из цикла
            except Exception as e:
                if "TerminatedByOtherGetUpdates" in str(e):
                    retry_count += 1
                    log_status(f"Конфликт экземпляров бота (попытка {retry_count}/{max_retries})", "WARNING")
                    
                    if retry_count < max_retries:
                        # Ждем дольше и пытаемся снова остановить конфликтующие процессы
                        log_status("Повторная попытка остановки конфликтующих экземпляров...", "INFO")
                        bot_manager.stop_existing_bot()
                        await asyncio.sleep(15)  # Увеличиваем время ожидания
                    else:
                        log_status("Превышено максимальное количество попыток", "ERROR")
                        return
                else:
                    log_status(f"Ошибка polling: {e}", "ERROR")
                    return
        
    except KeyboardInterrupt:
        log_status("Получен Ctrl+C, завершаем работу...", "INFO")
    except Exception as e:
        log_status(f"Критическая ошибка: {e}", "ERROR")
    finally:
        await shutdown()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nБот остановлен пользователем")
    except Exception as e:
        print(f"Критическая ошибка: {e}")
    finally:
        # Очистка при любом завершении
        if 'bot_manager' in globals() and bot_manager:
            bot_manager.cleanup()
