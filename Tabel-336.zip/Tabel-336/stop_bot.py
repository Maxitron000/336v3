
#!/usr/bin/env python3
"""
Скрипт для принудительной остановки всех экземпляров бота
"""
import os
import signal
import psutil
import time
from utils.console_logger import log_status

def kill_bot_processes():
    """Убить все процессы связанные с ботом"""
    killed_count = 0
    
    # Ищем процессы python с main.py
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            if proc.info['name'] == 'python' or proc.info['name'] == 'python3':
                cmdline = proc.info['cmdline']
                if cmdline and any('main.py' in arg for arg in cmdline):
                    log_status(f"Найден процесс бота: PID {proc.info['pid']}", "WARNING")
                    proc.terminate()
                    killed_count += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    
    if killed_count > 0:
        log_status(f"Отправлен сигнал завершения {killed_count} процессам", "INFO")
        time.sleep(3)
        
        # Принудительно убиваем если не завершились
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if proc.info['name'] == 'python' or proc.info['name'] == 'python3':
                    cmdline = proc.info['cmdline']
                    if cmdline and any('main.py' in arg for arg in cmdline):
                        log_status(f"Принудительно убиваем процесс: PID {proc.info['pid']}", "WARNING")
                        proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    
    # Удаляем PID файл
    pid_file = "/tmp/army_bot.pid"
    if os.path.exists(pid_file):
        os.remove(pid_file)
        log_status("PID файл удален", "SUCCESS")
    
    return killed_count

if __name__ == "__main__":
    log_status("🔄 Остановка всех экземпляров бота...", "INFO")
    count = kill_bot_processes()
    if count > 0:
        log_status(f"✅ Остановлено {count} процессов", "SUCCESS")
    else:
        log_status("ℹ️ Активные процессы бота не найдены", "INFO")
#!/usr/bin/env python3
"""
Скрипт для остановки экземпляров бота
"""
import os
import signal
import psutil
import sys
import time

def stop_existing_bot():
    """Остановить существующие экземпляры бота"""
    try:
        current_pid = os.getpid()
        stopped_count = 0
        
        for process in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if (process.info['pid'] != current_pid and 
                    process.info['name'] == 'python' and 
                    process.info['cmdline'] and 
                    any('main.py' in str(arg) for arg in process.info['cmdline'])):
                    
                    print(f"[INFO] Останавливаем процесс PID: {process.info['pid']}")
                    os.kill(process.info['pid'], signal.SIGTERM)
                    stopped_count += 1
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
                continue
        
        if stopped_count > 0:
            print(f"[INFO] Остановлено процессов: {stopped_count}")
            time.sleep(2)  # Даем время для корректного завершения
        else:
            print("[INFO] Активные процессы бота не найдены")
            
        return stopped_count
        
    except Exception as e:
        print(f"[ERROR] Ошибка остановки процессов: {e}")
        return 0

if __name__ == "__main__":
    print("[INFO] 🔄 Остановка всех экземпляров бота...")
    stop_existing_bot()
    print("[INFO] ✅ Процедура остановки завершена")
