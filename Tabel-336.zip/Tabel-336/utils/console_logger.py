import sys
import time
from datetime import datetime
import pytz
from config import TIMEZONE

# ANSI цвета для консоли
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'
    GRAY = '\033[90m'
    WHITE = '\033[97m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_YELLOW = '\033[93m'

def print_banner():
    """Красивый баннер запуска бота"""
    banner = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  {Colors.BRIGHT_YELLOW}🎖️  СИСТЕМА УЧЕТА ПЕРЕМЕЩЕНИЙ БОЙЦОВ                                  {Colors.CYAN}║
║  {Colors.BRIGHT_GREEN}🚀  ARMY ATTENDANCE TELEGRAM BOT                                      {Colors.CYAN}║
║                                                                              ║
║  {Colors.BRIGHT_BLUE}📍  Статус: {Colors.BRIGHT_GREEN}АКТИВЕН И ГОТОВ К РАБОТЕ{Colors.CYAN}                               ║
║  {Colors.BRIGHT_BLUE}🕐  Запущен: {Colors.WHITE}{datetime.now(pytz.timezone(TIMEZONE)).strftime('%d.%m.%Y %H:%M:%S')}{Colors.CYAN}                          ║
║  {Colors.BRIGHT_BLUE}🌍  Часовой пояс: {Colors.WHITE}Europe/Kaliningrad{Colors.CYAN}                                ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝{Colors.RESET}"""
    print(banner)

def print_system_check():
    """Проверка системы и компонентов"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}🔧 ПРОВЕРКА СИСТЕМНЫХ КОМПОНЕНТОВ:{Colors.RESET}")

    components = [
        ("База данных", "✅", Colors.GREEN),
        ("Telegram Bot API", "✅", Colors.GREEN),
        ("Клавиатуры и меню", "✅", Colors.GREEN),
        ("Админ панель", "✅", Colors.GREEN),
        ("Система ролей", "✅", Colors.GREEN),
        ("Валидация данных", "✅", Colors.GREEN),
        ("Экспорт в Excel", "✅", Colors.GREEN),
        ("Автоуведомления", "✅", Colors.GREEN),
        ("Keep-alive сервер", "✅", Colors.GREEN),
    ]

    for component, status, color in components:
        print(f"   {color}{status}{Colors.RESET} {component}")
        time.sleep(0.1)  # Анимация

def print_features():
    """Список доступных функций"""
    print(f"\n{Colors.BOLD}{Colors.YELLOW}⚡ ДОСТУПНЫЕ ФУНКЦИИ:{Colors.RESET}")

    features = [
        "📍 Отметки 'ПРИБЫЛ' / 'УБЫЛ' по 11 локациям",
        "📖 Персональный журнал для каждого бойца",
        "👨‍💼 Административная панель с отчетами",
        "📊 Фильтрация по датам и бойцам",
        "📤 Экспорт данных в Excel с цветовой заливкой",
        "🔔 Автоматические сводки в 19:00",
        "⏰ Напоминания в 20:30",
        "👑 Система ролей (главный/обычный админ)",
        "🛡️ Валидация ФИО и защита от ошибок",
        "🌐 Работа 24/7 через Keep-alive"
    ]

    for feature in features:
        print(f"   {Colors.CYAN}•{Colors.RESET} {feature}")

def print_admin_info():
    """Информация для админа"""
    print(f"\n{Colors.BOLD}{Colors.BRIGHT_YELLOW}👑 ИНФОРМАЦИЯ ДЛЯ АДМИНИСТРАТОРА:{Colors.RESET}")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Используйте команду /admin для входа в панель")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Автосводки приходят ежедневно в 19:00")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Напоминания о невернувшихся в 20:30")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Экспорт Excel доступен в админ панели")

def print_tech_info():
    """Техническая информация"""
    print(f"\n{Colors.BOLD}{Colors.GRAY}🔧 ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ:{Colors.RESET}")
    print(f"   {Colors.GRAY}• Flask сервер для keep-alive: порт 8080{Colors.RESET}")
    print(f"   {Colors.GRAY}• База данных: SQLite3{Colors.RESET}")
    print(f"   {Colors.GRAY}• Библиотеки: aiogram, openpyxl, pytz{Colors.RESET}")
    print(f"   {Colors.GRAY}• Поддержка: @Maxitron000{Colors.RESET}")

def print_footer():
    """Нижний колонтитул"""
    print(f"\n{Colors.BRIGHT_GREEN}{'='*80}")
    print(f"{Colors.BRIGHT_GREEN}🎯 БОТ УСПЕШНО ЗАПУЩЕН И ГОТОВ К ПРИЕМУ КОМАНД!")
    print(f"🔥 ВСЕ СИСТЕМЫ РАБОТАЮТ В ШТАТНОМ РЕЖИМЕ!")
    print(f"{'='*80}{Colors.RESET}")

def startup_sequence():
    """Полная последовательность запуска с анимацией"""
    print_banner()
    time.sleep(0.5)
    print_system_check() 
    time.sleep(0.5)
    print_features()
    time.sleep(0.5)
    print_admin_info()
    time.sleep(0.5)
    print_tech_info()
    time.sleep(0.5)
    print_footer()

# Добавляем недостающие импорты и классы
import time

class Colors:
    """Цвета для консоли"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_RED = '\033[91m'
    GRAY = '\033[90m'

def log_status(message, level="INFO"):
    """Логирование с цветами"""
    colors = {
        "SUCCESS": Colors.BRIGHT_GREEN,
        "INFO": Colors.BLUE,
        "WARNING": Colors.YELLOW,
        "ERROR": Colors.BRIGHT_RED
    }

    color = colors.get(level, Colors.RESET)
    timestamp = time.strftime("[%H:%M:%S]")
    print(f"{color}{timestamp} [{level}] {message}{Colors.RESET}")

def print_banner():
    """Красивый баннер запуска"""
    banner = f"""
{Colors.BRIGHT_GREEN}╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  {Colors.BRIGHT_YELLOW}🎖️  ARMY TELEGRAM BOT v2.0 - СИСТЕМА УЧЁТА ЛИЧНОГО СОСТАВА  🎖️{Colors.BRIGHT_GREEN}  ║
║                                                                              ║
║  {Colors.CYAN}📍  Локации: {Colors.WHITE}11 точек отметки (Госпиталь, ОБРМП, КПП и др.){Colors.BRIGHT_GREEN}      ║
║  {Colors.CYAN}👨‍💼  Админка: {Colors.WHITE}Полная система управления с ролями{Colors.BRIGHT_GREEN}                  ║
║  {Colors.CYAN}📊  Отчёты: {Colors.WHITE}Excel экспорт с цветовой заливкой{Colors.BRIGHT_GREEN}                     ║
║  {Colors.CYAN}🔔  Авто: {Colors.WHITE}Сводки 19:00, Напоминания 20:30 (MSK+1){Colors.BRIGHT_GREEN}                ║
║  {Colors.CYAN}🌍  Часовой пояс: {Colors.WHITE}Europe/Kaliningrad{Colors.BRIGHT_GREEN}                                ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝{Colors.RESET}"""
    print(banner)

def print_admin_info():
    """Информация для админа"""
    print(f"\n{Colors.BOLD}{Colors.BRIGHT_YELLOW}👑 ИНФОРМАЦИЯ ДЛЯ АДМИНИСТРАТОРА:{Colors.RESET}")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Используйте команду /admin для входа в панель")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Автосводки приходят ежедневно в 19:00")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Напоминания о невернувшихся в 20:30")
    print(f"   {Colors.BRIGHT_BLUE}•{Colors.RESET} Экспорт Excel доступен в админ панели")

def print_tech_info():
    """Техническая информация"""
    print(f"\n{Colors.BOLD}{Colors.GRAY}🔧 ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ:{Colors.RESET}")
    print(f"   {Colors.GRAY}• Flask сервер для keep-alive: порт 8080{Colors.RESET}")
    print(f"   {Colors.GRAY}• База данных: SQLite3{Colors.RESET}")
    print(f"   {Colors.GRAY}• Библиотеки: aiogram, openpyxl, pytz{Colors.RESET}")
    print(f"   {Colors.GRAY}• Поддержка: @Maxitron000{Colors.RESET}")

def print_footer():
    """Нижний колонтитул"""
    print(f"\n{Colors.BRIGHT_GREEN}{'='*80}")
    print(f"{Colors.BRIGHT_GREEN}🎯 БОТ УСПЕШНО ЗАПУЩЕН И ГОТОВ К ПРИЕМУ КОМАНД!")
    print(f"🔥 ВСЕ СИСТЕМЫ РАБОТАЮТ В ШТАТНОМ РЕЖИМЕ!")
    print(f"⚡ ОЖИДАНИЕ ПОЛЬЗОВАТЕЛЕЙ...{Colors.RESET}")
    print(f"{Colors.BRIGHT_GREEN}{'='*80}{Colors.RESET}\n")

def log_status(message, status="INFO"):
    """Логирование с временными метками"""
    now = datetime.now(pytz.timezone(TIMEZONE)).strftime('%H:%M:%S')
    colors = {
        "INFO": Colors.BLUE,
        "SUCCESS": Colors.GREEN,
        "WARNING": Colors.YELLOW,
        "ERROR": Colors.RED
    }
    color = colors.get(status, Colors.RESET)
    print(f"{Colors.GRAY}[{now}]{Colors.RESET} {color}[{status}]{Colors.RESET} {message}")

def startup_sequence():
    """Полная последовательность запуска"""
    print_banner()
    print_system_check()
    print_features()
    print_admin_info()
    print_tech_info()
    print_footer()

    # Логи инициализации
    log_status("Инициализация базы данных...", "INFO")
    time.sleep(0.5)
    log_status("База данных готова к работе", "SUCCESS")

    log_status("Регистрация обработчиков событий...", "INFO")
    time.sleep(0.3)
    log_status("Обработчики зарегистрированы", "SUCCESS")

    log_status("Запуск Telegram Bot polling...", "INFO")
    time.sleep(0.2)
    log_status("Polling запущен успешно", "SUCCESS")

    log_status("Keep-alive сервер активен на порту 8080", "SUCCESS")
    log_status("Бот готов к работе! 🚀", "SUCCESS")