
import asyncio
import logging
from typing import Dict, List
from aiogram import types

logger = logging.getLogger(__name__)

class MessageCleaner:
    """Система автоматического удаления сообщений для чистого интерфейса"""
    
    def __init__(self):
        self.pending_deletions: Dict[int, List[types.Message]] = {}
        self.cleanup_tasks: Dict[int, asyncio.Task] = {}
    
    def schedule_deletion(self, message: types.Message, delay_seconds: int = 1):
        """Запланировать удаление сообщения через указанное время"""
        if not message:
            return
            
        chat_id = message.chat.id
        
        # Инициализируем список для чата, если его нет
        if chat_id not in self.pending_deletions:
            self.pending_deletions[chat_id] = []
        
        self.pending_deletions[chat_id].append(message)
        
        # Создаем задачу для удаления
        task = asyncio.create_task(self._delete_after_delay(message, delay_seconds))
        self.cleanup_tasks[message.message_id] = task
    
    def schedule_multiple_deletion(self, messages: List[types.Message], delay_seconds: int = 1):
        """Запланировать удаление нескольких сообщений"""
        for message in messages:
            self.schedule_deletion(message, delay_seconds)
    
    async def _delete_after_delay(self, message: types.Message, delay: int):
        """Внутренний метод для удаления сообщения с задержкой"""
        try:
            await asyncio.sleep(delay)
            await message.delete()
            
            # Убираем из списка после удаления
            chat_id = message.chat.id
            if chat_id in self.pending_deletions:
                if message in self.pending_deletions[chat_id]:
                    self.pending_deletions[chat_id].remove(message)
                    
            # Убираем задачу
            if message.message_id in self.cleanup_tasks:
                del self.cleanup_tasks[message.message_id]
                
        except Exception as e:
            logger.warning(f"Не удалось удалить сообщение {message.message_id}: {e}")
    
    async def cleanup_chat_immediately(self, chat_id: int):
        """Немедленно очистить все запланированные сообщения в чате"""
        if chat_id not in self.pending_deletions:
            return
            
        messages_to_delete = self.pending_deletions[chat_id].copy()
        
        for message in messages_to_delete:
            try:
                await message.delete()
            except Exception as e:
                logger.warning(f"Ошибка при удалении сообщения: {e}")
        
        # Очищаем списки
        self.pending_deletions[chat_id] = []
    
    def cancel_deletion(self, message: types.Message):
        """Отменить запланированное удаление сообщения"""
        if message.message_id in self.cleanup_tasks:
            task = self.cleanup_tasks[message.message_id]
            if not task.done():
                task.cancel()
            del self.cleanup_tasks[message.message_id]
        
        # Убираем из списка
        chat_id = message.chat.id
        if chat_id in self.pending_deletions:
            if message in self.pending_deletions[chat_id]:
                self.pending_deletions[chat_id].remove(message)
    
    async def cleanup_all(self):
        """Завершить все задачи очистки при остановке бота"""
        for task in self.cleanup_tasks.values():
            if not task.done():
                task.cancel()
        
        self.cleanup_tasks.clear()
        self.pending_deletions.clear()

# Глобальный экземпляр для использования во всех хендлерах
message_cleaner = MessageCleaner()
