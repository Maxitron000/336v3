
import re
from services.db_service import user_exists, get_all_users

MAX_USERS = 100  # Лимит пользователей

def validate_fio(fio):
    """Строгая валидация ФИО по ТЗ"""
    if not fio or len(fio.strip()) < 5:
        return False, "❌ ФИО должно быть не короче 5 символов"
    
    # Проверка на бессмысленные строки
    nonsense_patterns = [
        r'^[а-яё]{1,3}$',  # ААА, ббб
        r'^\d+$',          # 123, 456
        r'^\.+$',          # ..., ....
        r'^[а-яё]\1+$',    # ааа, ббб
    ]
    
    for pattern in nonsense_patterns:
        if re.match(pattern, fio.lower().strip()):
            return False, "❌ Недопустимое ФИО. Пример: Иванов И.И."
    
    # Минимум две части (Фамилия Имя или Фамилия И.О.)
    parts = fio.strip().split()
    if len(parts) < 2:
        return False, "❌ ФИО должно содержать минимум 2 части. Пример: Иванов И.И."
    
    # Только кириллица, пробелы и точки
    if not re.match(r'^[а-яёА-ЯЁ\s\.]+$', fio):
        return False, "❌ ФИО должно содержать только русские буквы. Пример: Петров П.П."
    
    return True, "✅ ФИО корректно"

def check_user_limit():
    """Проверка лимита пользователей"""
    current_count = len(get_all_users())
    if current_count >= MAX_USERS:
        return False, f"❌ Достигнут лимит пользователей ({MAX_USERS})"
    return True, f"✅ Можно добавить ({current_count}/{MAX_USERS})"

def validate_user_addition(user_id, fio):
    """Комплексная валидация при добавлении пользователя"""
    # Проверка лимита
    limit_ok, limit_msg = check_user_limit()
    if not limit_ok:
        return False, limit_msg
    
    # Проверка дублирования ID
    if user_exists(user_id):
        return False, f"❌ Пользователь с ID {user_id} уже существует"
    
    # Проверка дублирования ФИО
    from services.db_service import find_user_by_fio
    if find_user_by_fio(fio):
        return False, f"❌ Боец с ФИО '{fio}' уже существует"
    
    # Валидация ФИО
    fio_ok, fio_msg = validate_fio(fio)
    if not fio_ok:
        return False, fio_msg
    
    return True, "✅ Данные корректны"

def validate_status_change(user_id, new_status):
    """Валидация изменения статуса (защита от двойных действий)"""
    from services.db_service import get_user_status
    
    current_status = get_user_status(user_id)
    if current_status == new_status:
        action = "прибыть" if new_status == "ПРИБЫЛ" else "убыть"
        return False, f"❌ Вы уже отмечены как {current_status}. Нельзя {action} дважды подряд!"
    
    return True, "✅ Смена статуса разрешена"
