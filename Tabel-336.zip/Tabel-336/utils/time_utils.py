from datetime import datetime
import pytz

TIMEZONE = pytz.timezone("Europe/Kaliningrad")

def kaliningrad_now():
    """Текущее время в Калининграде"""
    return datetime.now(TIMEZONE)

def kaliningrad_today():
    """Текущая дата в Калининграде"""
    return kaliningrad_now().strftime('%d.%m.%Y')

def format_datetime(dt):
    """Форматирование даты и времени"""
    return dt.strftime('%d.%m.%Y %H:%M:%S')