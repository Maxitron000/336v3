
import random

# Пример рандомных фраз для автоответов, напоминаний и прочего
JOIN_PHRASES = [
    "Рад снова видеть в строю!",
    "Добро пожаловать обратно!",
    "Отметка ПРИБЫЛ зафиксирована!",
    "Отличная работа, боец!",
    "Возвращение в часть зафиксировано!"
]

LEAVE_PHRASES = [
    "Будьте аккуратны вне части!",
    "Отметка УБЫЛ записана в журнал!",
    "Увидимся по возвращении!",
    "Хорошего дня вне части!",
    "Отметка убытия зафиксирована!"
]

REMINDER_PHRASES = [
    "Не забудьте отметиться при возвращении!",
    "Помните о дисциплине вне части!",
    "Будьте на связи!",
    "Соблюдайте установленное время!"
]

def get_random_phrase(phrase_type="join"):
    """Получить случайную фразу"""
    phrases = {
        "join": JOIN_PHRASES,
        "leave": LEAVE_PHRASES,
        "reminder": REMINDER_PHRASES
    }
    
    selected_phrases = phrases.get(phrase_type, JOIN_PHRASES)
    return random.choice(selected_phrases)
