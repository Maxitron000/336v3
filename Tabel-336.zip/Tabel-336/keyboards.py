
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

# === ГЛАВНЫЕ МЕНЮ ===

def get_user_main_menu(is_admin=False):
    """Главное меню пользователя с правильной структурой"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    
    # Первый ряд - основные действия
    keyboard.row(
        KeyboardButton("✅ ПРИБЫЛ"),
        KeyboardButton("❌ УБЫЛ")
    )
    
    # Второй ряд - информация
    keyboard.row(
        KeyboardButton("📖 Мой журнал"),
        KeyboardButton("ℹ️ Справка")
    )
    
    # Третий ряд - админ панель (если админ)
    if is_admin:
        keyboard.row(KeyboardButton("👨‍💼 Админ панель"))
    
    return keyboard

def user_main_menu():
    """Стандартное пользовательское меню"""
    return get_user_main_menu(False)

# === АДМИН МЕНЮ ===

admin_main_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
admin_main_menu.row(
    KeyboardButton("📊 Быстрая сводка"),
    KeyboardButton("👥 Управление л/с")
)
admin_main_menu.row(
    KeyboardButton("📖 Журнал событий"),
    KeyboardButton("⚙️ Настройки")
)
admin_main_menu.row(KeyboardButton("🔙 Назад в меню"))

# === МЕНЮ УПРАВЛЕНИЯ Л/С ===

personal_management_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
personal_management_menu.row(
    KeyboardButton("📋 Список всех"),
    KeyboardButton("➕ Добавить бойца")
)
personal_management_menu.row(
    KeyboardButton("✏️ Изменить ФИО"),
    KeyboardButton("❌ Удалить бойца")
)
personal_management_menu.row(
    KeyboardButton("📊 Статистика л/с"),
    KeyboardButton("🔙 Назад")
)

# === МЕНЮ КОМАНДИРОВ ===

commanders_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
commanders_menu.row(
    KeyboardButton("👀 Список командиров"),
    KeyboardButton("👑 Назначить командира")
)
commanders_menu.row(
    KeyboardButton("🔔 PUSH права"),
    KeyboardButton("📊 Права в отчётах")
)
commanders_menu.row(
    KeyboardButton("❌ Убрать командира"),
    KeyboardButton("🔙 Назад")
)

# === ЛОКАЦИИ (3 СТОЛБЦА) ===

def get_locations_keyboard():
    """Клавиатура локаций в 3 столбца"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)
    
    locations = [
        "🏥 Поликлиника", "⚓️ ОБРМП", "🌆 Калининград",
        "🛒 Магазин", "🍲 Столовая", "🏨 Госпиталь",
        "⚙️ Хоз. Работы", "🩺 ВВК", "🏛 МФЦ",
        "🚓 Патруль", "📝 Другое"
    ]
    
    # Добавляем по 3 кнопки в ряд
    for i in range(0, len(locations), 3):
        row_buttons = []
        for j in range(3):
            if i + j < len(locations):
                row_buttons.append(KeyboardButton(locations[i + j]))
        keyboard.row(*row_buttons)
    
    keyboard.row(KeyboardButton("🔙 Отмена"))
    return keyboard

# Готовые экземпляры
leave_locations_keyboard = get_locations_keyboard()
arrive_locations_keyboard = get_locations_keyboard()

# === ПОДТВЕРЖДЕНИЯ ===

def get_confirmation_keyboard(action_text="Подтвердить"):
    """Клавиатура подтверждения действий"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    keyboard.row(
        KeyboardButton("✅ Да, подтверждаю"),
        KeyboardButton("❌ Отмена")
    )
    return keyboard

def get_double_confirmation_keyboard():
    """Двойное подтверждение для критических действий"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    keyboard.row(KeyboardButton("Да, я уверен"))
    keyboard.row(KeyboardButton("❌ Отмена"))
    return keyboard

# === ЭКСПОРТ МЕНЮ ===

export_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
export_menu.row(
    KeyboardButton("📅 Вчера"),
    KeyboardButton("🎯 Сегодня")
)
export_menu.row(
    KeyboardButton("📊 7 дней"),
    KeyboardButton("📈 30 дней")
)
export_menu.row(
    KeyboardButton("📋 Все записи"),
    KeyboardButton("👥 Список бойцов")
)
export_menu.row(KeyboardButton("🔙 Назад"))

# === ЖУРНАЛ МЕНЮ ===

journal_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
journal_menu.row(
    KeyboardButton("📊 Все отметки"),
    KeyboardButton("📅 Отчёт за дату")
)
journal_menu.row(
    KeyboardButton("👤 Отчёт по бойцу"),
    KeyboardButton("📥 Экспорт данных")
)
journal_menu.row(KeyboardButton("🔙 Назад"))

# === НАСТРОЙКИ ===

settings_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
settings_menu.row(
    KeyboardButton("🔔 Уведомления"),
    KeyboardButton("👑 Управление админами")
)
settings_menu.row(
    KeyboardButton("⚠️ Опасная зона"),
    KeyboardButton("🔙 Назад")
)

notifications_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
notifications_menu.row(
    KeyboardButton("🔊 Вкл/выкл уведомления"),
    KeyboardButton("⏰ Настройка времени")
)
notifications_menu.row(
    KeyboardButton("📢 Типы уведомлений"),
    KeyboardButton("🌙 Режим тишины")
)
notifications_menu.row(KeyboardButton("🔙 Назад"))

admin_management_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
admin_management_menu.row(
    KeyboardButton("👀 Список админов"),
    KeyboardButton("👑 Назначить админа")
)
admin_management_menu.row(
    KeyboardButton("❌ Убрать админа"),
    KeyboardButton("🔄 Сменить роль")
)
admin_management_menu.row(KeyboardButton("🔙 Назад"))

danger_zone_menu = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
danger_zone_menu.row(KeyboardButton("🚨 Отметить всех прибывшими"))
danger_zone_menu.row(KeyboardButton("🗑️ Очистить журнал"))
danger_zone_menu.row(KeyboardButton("🔙 Назад"))

# === ПАГИНАЦИЯ (INLINE) ===

def get_pagination_keyboard(current_page, total_pages, prefix="page"):
    """Инлайн клавиатура для пагинации"""
    keyboard = InlineKeyboardMarkup(row_width=3)
    
    buttons = []
    
    # Кнопка "Назад"
    if current_page > 1:
        buttons.append(InlineKeyboardButton("⬅️", callback_data=f"{prefix}_{current_page-1}"))
    
    # Текущая страница
    buttons.append(InlineKeyboardButton(f"{current_page}/{total_pages}", callback_data="current"))
    
    # Кнопка "Вперёд"
    if current_page < total_pages:
        buttons.append(InlineKeyboardButton("➡️", callback_data=f"{prefix}_{current_page+1}"))
    
    keyboard.row(*buttons)
    return keyboard

# === УСТАРЕВШИЕ КНОПКИ ===

def get_outdated_menu():
    """Меню для устаревших кнопок"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    keyboard.row(KeyboardButton("🔄 Обновить меню"))
    return keyboard
