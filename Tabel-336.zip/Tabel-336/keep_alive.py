
from flask import Flask
from threading import Thread
import socket
import time

app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def find_free_port(start_port=8080):
    """Найти свободный порт начиная с указанного"""
    ports_to_try = [8080, 8081, 5000, 3000, 4000, 8000, 8008]
    
    for port in ports_to_try:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('0.0.0.0', port))
            sock.close()
            
            if result != 0:  # Порт свободен
                return port
        except Exception:
            continue
    
    # Если все порты заняты, возвращаем None
    return None

def run():
    port = find_free_port()
    if port is None:
        print("❌ Не удалось найти свободный порт для keep-alive сервера")
        return
    
    print(f"✅ Keep-alive сервер запускается на порту {port}")
    try:
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"❌ Ошибка запуска keep-alive сервера: {e}")

def keep_alive():
    """Запустить keep-alive сервер в отдельном потоке"""
    # Проверяем, не запущен ли уже сервер
    port = find_free_port()
    if port is None:
        print("⚠️ Все порты заняты, keep-alive сервер не будет запущен")
        return None
    
    t = Thread(target=run, daemon=True)
    t.start()
    
    # Даем время серверу запуститься
    time.sleep(1)
    return t
