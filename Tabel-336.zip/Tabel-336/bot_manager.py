import os
import signal
import time
import psutil
from utils.console_logger import log_status

class BotManager:
    """Менеджер для управления экземплярами бота"""

    def __init__(self):
        self.pid_file = "bot.pid"
        self.current_pid = os.getpid()

    def ensure_single_instance(self):
        """Обеспечить единственный экземпляр бота"""
        try:
            # Останавливаем существующие экземпляры
            stopped = self.stop_existing_bot()
            if stopped > 0:
                log_status(f"Остановлено {stopped} конфликтующих экземпляров", "INFO")
                time.sleep(3)  # Даем время для завершения

            # Записываем свой PID
            with open(self.pid_file, 'w') as f:
                f.write(str(self.current_pid))

            return True

        except Exception as e:
            log_status(f"Ошибка обеспечения единственного экземпляра: {e}", "ERROR")
            return False

    def stop_existing_bot(self):
        """Остановить существующие экземпляры бота"""
        stopped_count = 0

        try:
            for process in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if (process.info['pid'] != self.current_pid and 
                        process.info['name'] == 'python' and 
                        process.info['cmdline'] and 
                        any('main.py' in str(arg) for arg in process.info['cmdline'])):

                        os.kill(process.info['pid'], signal.SIGTERM)
                        stopped_count += 1

                except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
                    continue

        except Exception as e:
            log_status(f"Ошибка остановки процессов: {e}", "WARNING")

        return stopped_count

    def cleanup(self):
        """Очистка при завершении"""
        try:
            if os.path.exists(self.pid_file):
                os.remove(self.pid_file)
        except Exception:
            pass