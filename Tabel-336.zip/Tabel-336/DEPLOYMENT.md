# Деплой на Replit

1. Импортируй проект как Replit.
2. Заполни файл `.env` (или переменные окружения в интерфейсе Replit).
3. Установи зависимости:
    ```
    pip install -r requirements.txt
    ```
4. Запусти `main.py`.

## Как держать бот 24/7

- В проекте уже есть keep_alive.py
- Создай монитор на [uptimerobot.com](https://uptimerobot.com) (HTTP, 5 минут, адрес твоего Replit)
- Бот не будет засыпать

## Важные нюансы

- Все отчёты по времени Калининграда (Europe/Kaliningrad).
- Экспорт Excel с цветной заливкой.
- Сохраняй резервные копии базы (`services/db_service.db`).
