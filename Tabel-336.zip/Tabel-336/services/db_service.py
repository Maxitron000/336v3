import sqlite3
import os
from datetime import datetime, timedelta
import pytz
from openpyxl import Workbook
from openpyxl.styles import PatternFill
import shutil
import json
from config import ADMIN_ID

DB_PATH = os.path.join(os.path.dirname(__file__), "db_service.db")
BACKUP_PATH = os.path.join(os.path.dirname(__file__), "backups")
TIMEZONE = pytz.timezone("Europe/Kaliningrad")

def get_conn():
    """Получить подключение к базе с timeout для избежания блокировки"""
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    conn.execute("PRAGMA journal_mode=WAL;")  # Write-Ahead Logging для лучшей конкурентности
    return conn

def create_backup():
    """Создание автоматического бэкапа базы данных"""
    try:
        if not os.path.exists(BACKUP_PATH):
            os.makedirs(BACKUP_PATH)

        timestamp = datetime.now(TIMEZONE).strftime('%Y%m%d_%H%M%S')
        backup_file = os.path.join(BACKUP_PATH, f"backup_{timestamp}.db")

        shutil.copy2(DB_PATH, backup_file)

        # Оставляем только последние 10 бэкапов
        backups = sorted([f for f in os.listdir(BACKUP_PATH) if f.startswith('backup_')])
        if len(backups) > 10:
            for old_backup in backups[:-10]:
                os.remove(os.path.join(BACKUP_PATH, old_backup))

        return True, f"Бэкап создан: {backup_file}"
    except Exception as e:
        return False, f"Ошибка создания бэкапа: {e}"

def init_db():
    """Инициализация базы данных"""
    with get_conn() as conn:
        cur = conn.cursor()

        # Создание таблицы пользователей с дополнительными полями
        cur.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                fio TEXT NOT NULL,
                status TEXT DEFAULT 'УБЫЛ',
                show_in_reports BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Создание таблицы логов с заметками
        cur.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                date TEXT,
                time TEXT,
                action TEXT,
                location TEXT,
                fio TEXT,
                note TEXT DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
        ''')

        # Создание таблицы админов с расширенными правами
        cur.execute('''
            CREATE TABLE IF NOT EXISTS admins (
                user_id INTEGER PRIMARY KEY,
                fio TEXT,
                role TEXT DEFAULT 'admin',
                push_rights BOOLEAN DEFAULT 1,
                show_in_reports BOOLEAN DEFAULT 1,
                notify BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Создание таблицы настроек
        cur.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Добавляем недостающие колонки в существующие таблицы если они отсутствуют
        try:
            cur.execute("ALTER TABLE admins ADD COLUMN role TEXT DEFAULT 'admin'")
            conn.commit()
        except sqlite3.OperationalError:
            # Колонка уже существует
            pass

        # Добавляем колонку note в таблицу logs если она отсутствует
        try:
            cur.execute("ALTER TABLE logs ADD COLUMN note TEXT DEFAULT ''")
            conn.commit()
        except sqlite3.OperationalError:
            # Колонка уже существует
            pass

        # Добавляем колонку last_activity в таблицу users если она отсутствует
        try:
            cur.execute("ALTER TABLE users ADD COLUMN last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
            conn.commit()
        except sqlite3.OperationalError:
            # Колонка уже существует
            pass

        conn.commit()

        # Создаем автобэкап при инициализации
        create_backup()
        print("База данных инициализирована успешно")

# ----- USERS -----
def user_exists(user_id):
    """Проверяет, существует ли пользователь в базе"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,))
        return bool(cur.fetchone())

def find_user_by_fio(fio):
    """Найти пользователя по ФИО (для проверки дублирования)"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id, fio FROM users WHERE fio=?", (fio,))
        row = cur.fetchone()
        return {"user_id": row[0], "fio": row[1]} if row else None

def can_delete_user(user_id, requester_id):
    """Проверка возможности удаления пользователя"""
    # Нельзя удалить себя
    if user_id == requester_id:
        return False, "❌ Нельзя удалить самого себя"

    # Нельзя удалить последнего админа
    admins = get_admins()
    if len(admins) <= 1 and is_admin(user_id):
        return False, "❌ Нельзя удалить последнего админа"

    return True, "✅ Удаление разрешено"

def add_user(user_id, fio):
    """Добавляет нового пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO users (user_id, fio, status) VALUES (?, ?, ?)",
                    (user_id, fio, "УБЫЛ"))
        conn.commit()

def update_user_status(user_id, status):
    """Обновляет статус пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET status=? WHERE user_id=?",
                    (status, user_id))
        conn.commit()

def get_user_role(user_id):
    """Получить роль пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT role FROM admins WHERE user_id = ?", (user_id,))
        result = cur.fetchone()
        return result[0] if result else 'user'

def is_admin(user_id):
    """Проверить, является ли пользователь админом"""
    with get_conn() as conn:
        cur = conn.cursor()
        if user_id == ADMIN_ID:
            return True

        try:
            cur.execute("SELECT user_id FROM admins WHERE user_id = ?", (user_id,))
            result = cur.fetchone()
            return result is not None
        except sqlite3.OperationalError:
            # Если таблица или колонка не существует, возвращаем False
            return False

def valid_fio_in_db(user_id):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT fio FROM users WHERE user_id=?", (user_id,))
        res = cur.fetchone()
        return bool(res and res[0])

def save_fio_to_db(user_id, fio):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO users (user_id, fio, status) VALUES (?, ?, ?)",
                    (user_id, fio, "УБЫЛ"))
        conn.commit()

def get_all_users():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id, fio, status FROM users")
        users = [{"user_id": u[0], "fio": u[1], "status": u[2], "show_in_reports": True} for u in cur.fetchall()]
        return users

def get_users_for_reports():
    """Получить пользователей для отчетов"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id, fio, status FROM users")
        users = [{"user_id": u[0], "fio": u[1], "status": u[2]} for u in cur.fetchall()]
        return users

def change_user_fio(user_id, new_fio):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET fio=? WHERE user_id=?", (new_fio, user_id))
        conn.commit()

def get_user_status(user_id):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT status FROM users WHERE user_id=?", (user_id,))
        res = cur.fetchone()
        return res[0] if res else None

def set_user_status(user_id, status):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET status=?, last_activity=? WHERE user_id=?", 
                    (status, datetime.now(TIMEZONE), user_id))
        conn.commit()

def get_fio(user_id):
    """Получить ФИО пользователя по ID"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT fio FROM users WHERE user_id=?", (user_id,))
        res = cur.fetchone()
        return res[0] if res else ""

def toggle_user_reports_flag(user_id):
    """Переключить флаг show_in_reports для пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT show_in_reports FROM users WHERE user_id=?", (user_id,))
        current = cur.fetchone()

        if current:
            new_flag = not bool(current[0])
            cur.execute("UPDATE users SET show_in_reports=? WHERE user_id=?", (new_flag, user_id))
            conn.commit()
            return new_flag
        return False

# ----- LOGS -----
def add_user_action(user_id, action, location, note=""):
    with get_conn() as conn:
        cur = conn.cursor()
        now = datetime.now(TIMEZONE)
        date = now.strftime('%d.%m.%Y')
        time = now.strftime('%H:%M:%S')
        fio = get_fio(user_id)
        cur.execute("INSERT INTO logs (user_id, date, time, action, location, fio, note) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (user_id, date, time, action, location, fio, note))
        conn.commit()

def get_last_user_logs(user_id, limit=3):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT date, time, action, location, note FROM logs WHERE user_id=? ORDER BY date DESC, time DESC LIMIT ?", (user_id, limit))
        rows = cur.fetchall()
    return [
        {'datetime': f"{row[0]} {row[1]}", 'action': row[2], 'location': row[3], 'note': row[4]}
        for row in rows
    ]

def get_all_logs():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT date, time, fio, action, location, note FROM logs ORDER BY date DESC, time DESC")
        rows = cur.fetchall()
    return [
        {'date': row[0], 'time': row[1], 'fio': row[2], 'action': row[3], 'location': row[4], 'note': row[5]}
        for row in rows
    ]

def get_logs_by_date(date):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT date, time, fio, action, location, note FROM logs WHERE date=? ORDER BY time DESC", (date,))
        rows = cur.fetchall()
    return [
        {'date': row[0], 'time': row[1], 'fio': row[2], 'action': row[3], 'location': row[4], 'note': row[5]}
        for row in rows
    ]

def get_logs_by_user(user_id):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT date, time, fio, action, location, note FROM logs WHERE user_id=? ORDER BY date DESC, time DESC", (user_id,))
        rows = cur.fetchall()
    return [
        {'date': row[0], 'time': row[1], 'fio': row[2], 'action': row[3], 'location': row[4], 'note': row[5]}
        for row in rows
    ]

def clear_logs():
    with get_conn() as conn:
        cur = conn.cursor()
        # Создаем бэкап перед очисткой
        create_backup()
        cur.execute("DELETE FROM logs")
        conn.commit()

# ----- EXPORT TO EXCEL -----
def get_logs_by_period(days):
    """Получить логи за указанное количество дней"""
    with get_conn() as conn:
        cur = conn.cursor()
        if days == 0:  # Сегодня
            today = datetime.now(TIMEZONE).strftime('%d.%m.%Y')
            cur.execute("SELECT date, time, fio, action, location, note FROM logs WHERE date=? ORDER BY date DESC, time DESC", (today,))
        elif days == -1:  # Вчера
            yesterday = (datetime.now(TIMEZONE) - timedelta(days=1)).strftime('%d.%m.%Y')
            cur.execute("SELECT date, time, fio, action, location, note FROM logs WHERE date=? ORDER BY date DESC, time DESC", (yesterday,))
        else:  # За N дней
            start_date = (datetime.now(TIMEZONE) - timedelta(days=days)).strftime('%d.%m.%Y')
            cur.execute("""
                SELECT date, time, fio, action, location, note
                FROM logs 
                WHERE date >= ? 
                ORDER BY date DESC, time DESC
            """, (start_date,))
        rows = cur.fetchall()
    return [
        {'date': row[0], 'time': row[1], 'fio': row[2], 'action': row[3], 'location': row[4], 'note': row[5]}
        for row in rows
    ]

def export_logs_to_excel(period_name="все", logs=None):
    if logs is None:
        logs = get_all_logs()

    file_path = f"export_logs_{period_name}.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Логи"

    # Заголовки
    headers = ["Дата", "Время", "ФИО", "Действие", "Локация", "Заметка"]
    for col, header in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=header)

    # Цвета для заливки
    green = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")

    # Добавляем данные
    for row_idx, log in enumerate(logs, 2):
        ws.cell(row=row_idx, column=1, value=log['date'])
        ws.cell(row=row_idx, column=2, value=log['time'])
        ws.cell(row=row_idx, column=3, value=log['fio'])
        ws.cell(row=row_idx, column=4, value=log['action'])
        ws.cell(row=row_idx, column=5, value=log['location'])
        ws.cell(row=row_idx, column=6, value=log.get('note', ''))

        # Применяем цвет в зависимости от действия
        color = green if log['action'] == "ПРИБЫЛ" else red
        for col in range(1, 7):
            ws.cell(row=row_idx, column=col).fill = color

    wb.save(file_path)
    return file_path

def export_users_to_excel():
    users = get_all_users()
    file_path = "export_users.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Бойцы"

    # Заголовки
    headers = ["ФИО", "Статус", "В отчётах"]
    for col, header in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=header)

    # Добавляем данные
    for row_idx, user in enumerate(users, 2):
        ws.cell(row=row_idx, column=1, value=user['fio'])
        ws.cell(row=row_idx, column=2, value=user['status'])
        ws.cell(row=row_idx, column=3, value="Да" if user.get('show_in_reports', True) else "Нет")

    wb.save(file_path)
    return file_path

def get_absent_users():
    """Получить список отсутствующих бойцов с их последними действиями"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT DISTINCT u.user_id, u.fio, u.status,
                   l.location as last_location,
                   l.date || ' ' || l.time as last_time
            FROM users u
            LEFT JOIN logs l ON u.user_id = l.user_id 
            WHERE u.status = 'УБЫЛ'
            AND l.id = (
                SELECT MAX(id) FROM logs 
                WHERE user_id = u.user_id 
                AND action = 'УБЫЛ'
            )
        """)
        rows = cur.fetchall()
    return [
        {
            'user_id': row[0],
            'fio': row[1], 
            'status': row[2],
            'last_location': row[3] or 'Неизвестно',
            'last_time': row[4] or 'Неизвестно'
        }
        for row in rows
    ]

def mark_all_present():
    """Отметить всех бойцов как прибывших"""
    with get_conn() as conn:
        cur = conn.cursor()
        # Получаем всех бойцов
        cur.execute("SELECT user_id, fio FROM users")
        users = cur.fetchall()

        count = 0
        for user in users:
            user_id, fio = user
            # Обновляем статус
            cur.execute("UPDATE users SET status = 'ПРИБЫЛ' WHERE user_id = ?", (user_id,))
            # Добавляем запись в логи
            add_user_action(user_id, "ПРИБЫЛ", "Массовая отметка админом")
            count += 1

        conn.commit()
        # Создаем бэкап после массовых изменений
        create_backup()
    return count

def add_new_user(user_id, fio):
    """Добавить нового пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO users (user_id, fio, status) 
            VALUES (?, ?, 'УБЫЛ')
        """, (user_id, fio))
        conn.commit()

def delete_user(user_id):
    """Удалить пользователя"""
    with get_conn() as conn:
        cur = conn.cursor()
        # Создаем бэкап перед удалением
        create_backup()
        # Удаляем из users
        cur.execute("DELETE FROM users WHERE user_id = ?", (user_id,))
        # Удаляем из логов
        cur.execute("DELETE FROM logs WHERE user_id = ?", (user_id,))
        # Удаляем из админов
        cur.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
        conn.commit()

# ----- ADMINS & ROLES -----
def get_admins():
    """Получить список всех админов"""
    with get_conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute("SELECT user_id, fio, role, push_rights, show_in_reports, notify FROM admins")
            rows = cur.fetchall()

            admins = []
            # Добавляем главного админа из конфига
            from config import ADMIN_ID
            main_admin = {
                "user_id": ADMIN_ID, 
                "fio": "Главный админ", 
                "role": "main",
                "push_rights": True,
                "show_in_reports": True,
                "notify": True
            }
            admins.append(main_admin)

            # Добавляем остальных админов из базы
            for row in rows:
                if row[0] != ADMIN_ID:  # Избегаем дублирования главного админа
                    admins.append({
                        "user_id": row[0],
                        "fio": row[1],
                        "role": row[2],
                        "push_rights": bool(row[3]),
                        "show_in_reports": bool(row[4]),
                        "notify": bool(row[5])
                    })

            return admins
        except sqlite3.OperationalError:
            # Если таблица или колонки не существуют, возвращаем пустой список
            return []

def set_admin_role(user_id, role):
    """Установить роль админа"""
    with get_conn() as conn:
        cur = conn.cursor()
        # Получаем ФИО пользователя
        cur.execute("SELECT fio FROM users WHERE user_id = ?", (user_id,))
        user_data = cur.fetchone()
        if not user_data:
            return False

        fio = user_data[0]

        if role == 'user':
            # Удаляем из админов
            cur.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
        else:
            # Добавляем/обновляем админа
            cur.execute("""
                INSERT OR REPLACE INTO admins (user_id, fio, role, push_rights, show_in_reports, notify) 
                VALUES (?, ?, ?, 1, 1, 1)
            """, (user_id, fio, role))

        conn.commit()
        return True

def toggle_admin_notify(user_id):
    """Переключить уведомления для админа"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT notify FROM admins WHERE user_id = ?", (user_id,))
        current = cur.fetchone()

        if current:
            new_notify = not bool(current[0])
            cur.execute("UPDATE admins SET notify = ? WHERE user_id = ?", (new_notify, user_id))
            conn.commit()
            return new_notify
        return False

def toggle_admin_push_rights(user_id):
    """Переключить PUSH права для админа"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT push_rights FROM admins WHERE user_id = ?", (user_id,))
        current = cur.fetchone()

        if current:
            new_rights = not bool(current[0])
            cur.execute("UPDATE admins SET push_rights = ? WHERE user_id = ?", (new_rights, user_id))
            conn.commit()
            return new_rights
        return False

def is_main_admin(user_id):
    """Проверить, является ли пользователь главным админом"""
    with get_conn() as conn:
        cur = conn.cursor()
        return get_user_role(user_id) == 'main'

def find_user(user_input):
    """Поиск пользователя по ID или ФИО (универсальная функция)"""
    with get_conn() as conn:
        cur = conn.cursor()

        if str(user_input).isdigit():
            # Поиск по ID
            cur.execute("SELECT user_id, fio, status FROM users WHERE user_id=?", (int(user_input),))
        else:
            # Поиск по ФИО (точное совпадение сначала, потом частичное)
            cur.execute("SELECT user_id, fio, status FROM users WHERE fio=?", (user_input,))
            result = cur.fetchone()
            
            if not result:
                # Если точного совпадения нет, ищем частично
                cur.execute("SELECT user_id, fio, status FROM users WHERE fio LIKE ?", (f"%{user_input}%",))
                result = cur.fetchone()
            else:
                pass  # Результат уже найден

        if not 'result' in locals():
            result = cur.fetchone()
            
        if result:
            return {
                'user_id': result[0],
                'fio': result[1], 
                'status': result[2]
            }
        return None

def find_user_by_fio(fio):
    """Поиск пользователя по точному ФИО"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT user_id, fio, status FROM users WHERE fio=?", (fio,))
        result = cur.fetchone()
        if result:
            return {
                'user_id': result[0],
                'fio': result[1], 
                'status': result[2]
            }
        return None

# ----- НАСТРОЙКИ -----
def get_setting(key, default=None):
    """Получить настройку"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT value FROM settings WHERE key=?", (key,))
        result = cur.fetchone()
        return result[0] if result else default

def set_setting(key, value):
    """Установить настройку"""
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT OR REPLACE INTO settings (key, value, updated_at) 
            VALUES (?, ?, ?)
        """, (key, str(value), datetime.now(TIMEZONE)))
        conn.commit()