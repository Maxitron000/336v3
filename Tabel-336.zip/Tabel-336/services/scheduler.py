
import asyncio
import logging
from datetime import datetime, time
import pytz
from aiogram import Bot
from config import ADMIN_ID, TIMEZONE
from services.db_service import get_absent_users, get_all_users, get_logs_by_period
from utils.console_logger import log_status

logger = logging.getLogger(__name__)

class TaskScheduler:
    """Планировщик для автоматических задач бота"""
    
    def __init__(self, bot: Bot):
        self.bot = bot
        self.timezone = pytz.timezone(TIMEZONE)
        self.running = False
        self.tasks = []
    
    async def start(self):
        """Запустить планировщик"""
        if self.running:
            return
            
        self.running = True
        log_status("Планировщик автозадач запущен", "SUCCESS")
        
        # Создаем задачи для разных уведомлений
        self.tasks = [
            asyncio.create_task(self._daily_summary_task()),
            asyncio.create_task(self._absent_reminder_task()),
            asyncio.create_task(self._system_health_check())
        ]
    
    async def stop(self):
        """Остановить планировщик"""
        self.running = False
        
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        log_status("Планировщик автозадач остановлен", "INFO")
    
    async def _daily_summary_task(self):
        """Задача ежедневной сводки в 19:00"""
        while self.running:
            try:
                now = datetime.now(self.timezone)
                target_time = time(19, 0)  # 19:00
                
                # Вычисляем время до следующей сводки
                next_run = self._get_next_run_time(target_time)
                sleep_seconds = (next_run - now).total_seconds()
                
                if sleep_seconds > 0:
                    await asyncio.sleep(sleep_seconds)
                
                if self.running:
                    await self._send_daily_summary()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_status(f"Ошибка в задаче ежедневной сводки: {e}", "ERROR")
                await asyncio.sleep(3600)  # Ждем час при ошибке
    
    async def _absent_reminder_task(self):
        """Задача напоминания о невернувшихся в 20:30"""
        while self.running:
            try:
                now = datetime.now(self.timezone)
                target_time = time(20, 30)  # 20:30
                
                next_run = self._get_next_run_time(target_time)
                sleep_seconds = (next_run - now).total_seconds()
                
                if sleep_seconds > 0:
                    await asyncio.sleep(sleep_seconds)
                
                if self.running:
                    await self._send_absent_reminder()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_status(f"Ошибка в задаче напоминаний: {e}", "ERROR")
                await asyncio.sleep(3600)
    
    async def _system_health_check(self):
        """Проверка работоспособности системы каждые 6 часов"""
        while self.running:
            try:
                await asyncio.sleep(6 * 3600)  # 6 часов
                
                if self.running:
                    await self._check_system_health()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_status(f"Ошибка в проверке системы: {e}", "ERROR")
                await asyncio.sleep(3600)
    
    def _get_next_run_time(self, target_time: time) -> datetime:
        """Получить следующее время выполнения"""
        now = datetime.now(self.timezone)
        target = now.replace(
            hour=target_time.hour, 
            minute=target_time.minute, 
            second=0, 
            microsecond=0
        )
        
        # Если время уже прошло, переносим на следующий день
        if target <= now:
            target = target.replace(day=target.day + 1)
        
        return target
    
    async def _send_daily_summary(self):
        """Отправить ежедневную сводку"""
        try:
            absent_users = get_absent_users()
            all_users = get_all_users()
            present_count = len(all_users) - len(absent_users)
            
            # Получаем сводку за сегодня
            today_logs = get_logs_by_period(0)
            
            summary_text = f"""
🏛️ <b>ЕЖЕДНЕВНАЯ СВОДКА</b>
📅 {datetime.now(self.timezone).strftime('%d.%m.%Y')}

👥 <b>ЛИЧНЫЙ СОСТАВ:</b>
• Всего бойцов: {len(all_users)}
• ✅ Присутствует: {present_count}
• ❌ Отсутствует: {len(absent_users)}

📊 <b>АКТИВНОСТЬ ЗА ДЕНЬ:</b>
• Всего отметок: {len(today_logs)}
"""
            
            if absent_users:
                summary_text += "\n🚨 <b>ОТСУТСТВУЮЩИЕ:</b>\n"
                for user in absent_users[:10]:  # Показываем первых 10
                    last_location = user.get('last_location', 'Неизвестно')
                    last_time = user.get('last_time', 'Неизвестно')
                    summary_text += f"• {user['fio']} → {last_location} ({last_time})\n"
                
                if len(absent_users) > 10:
                    summary_text += f"• ... и ещё {len(absent_users) - 10} бойцов\n"
            
            summary_text += f"\n⏰ Время сводки: {datetime.now(self.timezone).strftime('%H:%M:%S')}"
            summary_text += f"\n🕐 Следующая сводка: завтра в 19:00"
            
            await self.bot.send_message(
                ADMIN_ID, 
                summary_text, 
                parse_mode='HTML'
            )
            
            log_status("Ежедневная сводка отправлена", "SUCCESS")
            
        except Exception as e:
            log_status(f"Ошибка отправки ежедневной сводки: {e}", "ERROR")
    
    async def _send_absent_reminder(self):
        """Отправить напоминание о невернувшихся"""
        try:
            absent_users = get_absent_users()
            
            if not absent_users:
                log_status("Все бойцы на месте - напоминание не требуется", "INFO")
                return
            
            reminder_text = f"""
⚠️ <b>НАПОМИНАНИЕ О НЕВЕРНУВШИХСЯ</b>
🕘 {datetime.now(self.timezone).strftime('%H:%M')} - Время проверки

🚨 <b>НЕ ОТМЕТИЛИСЬ КАК ПРИБЫВШИЕ:</b>
"""
            
            for user in absent_users:
                last_location = user.get('last_location', 'Неизвестно')
                last_time = user.get('last_time', 'Неизвестно')
                reminder_text += f"• {user['fio']} → {last_location} ({last_time})\n"
            
            reminder_text += f"\n📋 Всего отсутствует: {len(absent_users)} бойцов"
            reminder_text += f"\n⏰ Следующая проверка: завтра в 20:30"
            
            await self.bot.send_message(
                ADMIN_ID, 
                reminder_text, 
                parse_mode='HTML'
            )
            
            log_status(f"Напоминание отправлено ({len(absent_users)} отсутствующих)", "SUCCESS")
            
        except Exception as e:
            log_status(f"Ошибка отправки напоминания: {e}", "ERROR")
    
    async def _check_system_health(self):
        """Проверить здоровье системы"""
        try:
            # Простая проверка - попытка получить данные из БД
            users_count = len(get_all_users())
            logs_count = len(get_logs_by_period(1))  # За последний день
            
            if users_count == 0:
                health_text = "⚠️ <b>СИСТЕМНОЕ ПРЕДУПРЕЖДЕНИЕ</b>\n\nВ базе данных нет пользователей!"
                await self.bot.send_message(ADMIN_ID, health_text, parse_mode='HTML')
            
            log_status(f"Проверка системы: {users_count} пользователей, {logs_count} записей за день", "INFO")
            
        except Exception as e:
            # Критическая ошибка - уведомляем админа
            error_text = f"""
🚨 <b>КРИТИЧЕСКАЯ ОШИБКА СИСТЕМЫ</b>

❌ Ошибка: {str(e)}
🕐 Время: {datetime.now(self.timezone).strftime('%d.%m.%Y %H:%M:%S')}

Требуется немедленная проверка бота!
"""
            try:
                await self.bot.send_message(ADMIN_ID, error_text, parse_mode='HTML')
            except:
                pass
            
            log_status(f"Критическая ошибка системы: {e}", "ERROR")

# Глобальный планировщик
scheduler = None

async def init_scheduler(bot: Bot):
    """Инициализировать и запустить планировщик"""
    global scheduler
    scheduler = TaskScheduler(bot)
    await scheduler.start()

async def stop_scheduler():
    """Остановить планировщик"""
    global scheduler
    if scheduler:
        await scheduler.stop()
