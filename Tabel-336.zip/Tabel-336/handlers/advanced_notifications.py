from aiogram import Dispatcher

# Дополнительные уведомления, например, smart-мониторинг, сигнал о "зависшем" боте, и т.д.

def register_advanced_notification_handlers(dp: Dispatcher):
    pass
