
from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from keyboards import (
    user_main_menu, leave_locations_keyboard, arrive_locations_keyboard, 
    get_user_main_menu, get_outdated_menu
)
from services.db_service import (
    user_exists, add_user, get_user_status, update_user_status,
    add_user_action, get_last_user_logs, is_admin, get_fio
)
from utils.validators import validate_fio, validate_status_change
from utils.message_cleaner import message_cleaner
from config import ADMIN_ID
import asyncio
import json
import os
from datetime import datetime

class UserStates(StatesGroup):
    waiting_for_fio = State()
    waiting_for_note = State()
    choosing_location = State()
    waiting_for_custom_location = State()

# === БАЗОВЫЕ ХЕНДЛЕРЫ ===

async def cmd_start(message: types.Message):
    """Команда /start с проверкой ФИО"""
    user_id = message.from_user.id
    
    # Проверяем, есть ли у пользователя валидное ФИО
    if not user_exists(user_id):
        welcome_text = """
🎖️ <b>ДОБРО ПОЖАЛОВАТЬ В СИСТЕМУ УЧЕТА!</b>

📝 Для начала работы необходимо зарегистрироваться.

<b>Введите ваше ФИО:</b>
<i>Пример: Иванов И.И.</i>

<b>Требования:</b>
• Минимум 2 части (Фамилия Имя)
• Только русские буквы
• Не короче 5 символов

❌ <i>Недопустимо: ААА, 123, Х</i>
        """
        await message.answer(welcome_text, parse_mode='HTML')
        await UserStates.waiting_for_fio.set()
        return
    
    # Показываем главное меню
    menu = get_user_main_menu(is_admin(user_id))
    welcome_text = f"""
🏠 <b>ГЛАВНОЕ МЕНЮ</b>

👤 {get_fio(user_id)}
📍 Статус: <b>{get_user_status(user_id)}</b>

Выберите действие:
    """
    
    await message.answer(welcome_text, reply_markup=menu, parse_mode='HTML')

async def process_custom_location(message: types.Message, state: FSMContext):
    """Обработка ввода произвольной локации"""
    user_id = message.from_user.id
    custom_location = message.text.strip()
    
    # Автоудаление ввода пользователя
    message_cleaner.schedule_deletion(message, 1)
    
    # Обработка отмены
    if custom_location == "🔙 Отмена":
        await state.finish()
        menu = get_user_main_menu(is_admin(user_id))
        await message.answer("❌ Действие отменено", reply_markup=menu)
        return
    
    # Валидация произвольной локации
    if len(custom_location) < 3:
        await message.answer(
            "❌ Слишком короткая локация! Минимум 3 символа.\n\n✍️ Попробуйте еще раз:",
            parse_mode='HTML'
        )
        return
    
    if len(custom_location) > 100:
        await message.answer(
            "❌ Слишком длинная локация! Максимум 100 символов.\n\n✍️ Попробуйте еще раз:",
            parse_mode='HTML'
        )
        return
    
    # Проверка на допустимые символы (русские буквы, цифры, пробелы, базовые знаки)
    import re
    if not re.match(r'^[а-яё\d\s\.,!?\-"\'()]+$', custom_location, re.IGNORECASE):
        await message.answer(
            "❌ Недопустимые символы! Используйте только русские буквы и цифры.\n\n✍️ Попробуйте еще раз:",
            parse_mode='HTML'
        )
        return
    
    # Получаем данные состояния
    state_data = await state.get_data()
    action = state_data.get("action", "УБЫЛ")
    
    # Формируем итоговую локацию с префиксом
    final_location = f"📝 {custom_location}"
    
    # Обновляем статус и добавляем запись
    update_user_status(user_id, action)
    add_user_action(user_id, action, final_location)
    
    # Завершаем состояние
    await state.finish()
    
    # Загружаем уведомления из файла
    notifications = load_notifications()
    status_messages = notifications.get("status_changes", {})
    template = status_messages.get("departed", ["❌ {fio} УБЫЛ в {location}"])[0]
    
    result_text = template.format(fio=get_fio(user_id), location=final_location)
    result_text += f"\n📍 Статус обновлен: <b>УБЫЛ</b>"
    result_text += f"\n⏰ Время: {datetime.now().strftime('%H:%M:%S')}"
    
    # Возвращаем главное меню
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(result_text, reply_markup=menu, parse_mode='HTML')

async def process_fio_registration(message: types.Message, state: FSMContext):
    """Обработка регистрации ФИО с валидацией"""
    user_id = message.from_user.id
    fio = message.text.strip()
    
    # Автоудаление ввода пользователя
    message_cleaner.schedule_deletion(message, 1)
    
    # Валидация ФИО
    is_valid, error_msg = validate_fio(fio)
    if not is_valid:
        await message.answer(
            f"{error_msg}\n\n📝 Попробуйте еще раз:\n<i>Пример: Петров П.П.</i>",
            parse_mode='HTML'
        )
        return
    
    # Проверка на дублирование
    from services.db_service import find_user_by_fio
    existing_user = find_user_by_fio(fio)
    if existing_user:
        await message.answer(
            f"❌ Боец с ФИО '{fio}' уже зарегистрирован!\n\n📝 Введите другое ФИО:",
            parse_mode='HTML'
        )
        return
    
    # Регистрируем пользователя
    add_user(user_id, fio)
    await state.finish()
    
    success_text = f"""
✅ <b>РЕГИСТРАЦИЯ ЗАВЕРШЕНА!</b>

👤 ФИО: {fio}
📍 Статус: УБЫЛ
🎖️ Добро пожаловать в систему!

Теперь вы можете отмечать прибытие и убытие.
    """
    
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(success_text, reply_markup=menu, parse_mode='HTML')

async def arrive_action(message: types.Message):
    """Обработка действия ПРИБЫЛ без выбора локации"""
    user_id = message.from_user.id
    
    # Проверка регистрации
    if not user_exists(user_id):
        await show_registration_required(message)
        return
    
    # Валидация смены статуса
    is_valid, error_msg = validate_status_change(user_id, "ПРИБЫЛ")
    if not is_valid:
        await message.answer(
            f"{error_msg}\n\nВыберите другое действие:",
            reply_markup=get_user_main_menu(is_admin(user_id)),
            parse_mode='HTML'
        )
        return
    
    # Сразу обновляем статус без выбора локации
    update_user_status(user_id, "ПРИБЫЛ")
    add_user_action(user_id, "ПРИБЫЛ", "Прибыл в расположение")
    
    # Загружаем уведомления из файла
    notifications = load_notifications()
    status_messages = notifications.get("status_changes", {})
    template = status_messages.get("arrived", ["✅ {fio} ПРИБЫЛ"])[0]
    
    result_text = template.format(fio=get_fio(user_id))
    result_text += f"\n📍 Статус обновлен: <b>ПРИБЫЛ</b>"
    result_text += f"\n⏰ Время: {datetime.now().strftime('%H:%M:%S')}"
    
    # Возвращаем главное меню
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(result_text, reply_markup=menu, parse_mode='HTML')

async def depart_action(message: types.Message):
    """Обработка действия УБЫЛ с валидацией"""
    user_id = message.from_user.id
    
    # Проверка регистрации
    if not user_exists(user_id):
        await show_registration_required(message)
        return
    
    # Валидация смены статуса
    is_valid, error_msg = validate_status_change(user_id, "УБЫЛ")
    if not is_valid:
        await message.answer(
            f"{error_msg}\n\nВыберите другое действие:",
            reply_markup=get_user_main_menu(is_admin(user_id)),
            parse_mode='HTML'
        )
        return
    
    # Показываем выбор локации
    instruction_text = """
📤 <b>ВЫБЕРИТЕ ЛОКАЦИЮ УБЫТИЯ:</b>

🏥 Поликлиника - завершение медобслуживания
⚓️ ОБРМП - убытие с основного расположения
🌆 Калининград - возвращение из города
🛒 Магазин - завершение закупок
🍲 Столовая - завершение приема пищи
🏨 Госпиталь - выписка из госпиталя
⚙️ Хоз. Работы - завершение хозработ
🩺 ВВК - завершение ВВК
🏛 МФЦ - завершение документооборота
🚓 Патруль - завершение патрулирования
📝 Другое - завершение иных задач

<i>Выберите локацию из кнопок ниже:</i>
    """
    
    await message.answer(
        instruction_text, 
        reply_markup=leave_locations_keyboard, 
        parse_mode='HTML'
    )
    await UserStates.choosing_location.set()

async def process_location_choice(message: types.Message, state: FSMContext):
    """Обработка выбора локации"""
    user_id = message.from_user.id
    location = message.text.strip()
    
    # Проверяем валидность локации
    valid_locations = [
        "🏥 Поликлиника", "⚓️ ОБРМП", "🌆 Калининград", "🛒 Магазин",
        "🍲 Столовая", "🏨 Госпиталь", "⚙️ Хоз. Работы", "🩺 ВВК",
        "🏛 МФЦ", "🚓 Патруль", "📝 Другое"
    ]
    
    # Обработка отмены
    if location == "🔙 Отмена":
        await state.finish()
        menu = get_user_main_menu(is_admin(user_id))
        await message.answer("❌ Действие отменено", reply_markup=menu)
        return
    
    # Обработка "Другое" - запрос произвольной локации
    if location == "📝 Другое":
        await state.update_data(action="УБЫЛ")
        await UserStates.waiting_for_custom_location.set()
        
        custom_location_text = """
📝 <b>ВВЕДИТЕ ЛОКАЦИЮ УБЫТИЯ:</b>

Напишите, куда убываете:
<i>Например: "в магазин Пятёрочка", "в военкомат", "домой в отпуск"</i>

<b>Требования:</b>
• Минимум 3 символа
• Максимум 100 символов
• Только русские буквы и цифры

✍️ Введите локацию:
        """
        
        # Создаем простую клавиатуру только с отменой
        from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
        cancel_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
        cancel_keyboard.row(KeyboardButton("🔙 Отмена"))
        
        await message.answer(custom_location_text, reply_markup=cancel_keyboard, parse_mode='HTML')
        return
    
    # Проверка валидности локации
    if location not in valid_locations:
        # НЕ завершаем состояние, оставляем пользователя в режиме выбора
        await message.answer(
            "❌ Неверная локация! Выберите из предложенных кнопок:",
            reply_markup=arrive_locations_keyboard
        )
        return
    
    # Это состояние теперь используется только для убытия
    new_status = "УБЫЛ"
    
    # Обновляем статус и добавляем запись
    update_user_status(user_id, new_status)
    add_user_action(user_id, new_status, location)
    
    # Завершаем состояние ТОЛЬКО после успешной обработки
    await state.finish()
    
    # Загружаем уведомления из файла
    notifications = load_notifications()
    status_messages = notifications.get("status_changes", {})
    template = status_messages.get("departed", ["❌ {fio} УБЫЛ в {location}"])[0]
    
    result_text = template.format(fio=get_fio(user_id), location=location)
    result_text += f"\n📍 Статус обновлен: <b>УБЫЛ</b>"
    result_text += f"\n⏰ Время: {datetime.now().strftime('%H:%M:%S')}"
    
    # Возвращаем главное меню
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(result_text, reply_markup=menu, parse_mode='HTML')

async def my_journal(message: types.Message):
    """Персональный журнал пользователя"""
    user_id = message.from_user.id
    
    if not user_exists(user_id):
        await show_registration_required(message)
        return
    
    logs = get_last_user_logs(user_id, 10)
    fio = get_fio(user_id)
    current_status = get_user_status(user_id)
    
    text = f"📖 <b>ЖУРНАЛ: {fio}</b>\n\n"
    text += f"📍 Текущий статус: <b>{current_status}</b>\n\n"
    
    if logs:
        text += "📋 <b>Последние 10 записей:</b>\n\n"
        for i, log in enumerate(logs, 1):
            action_emoji = "✅" if log['action'] == "ПРИБЫЛ" else "❌"
            text += f"{i}. {action_emoji} {log['datetime']}\n"
            text += f"   📍 {log['location']}\n"
            if log.get('note'):
                text += f"   📝 {log['note']}\n"
            text += "\n"
    else:
        text += "📝 Записей пока нет"
    
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(text, reply_markup=menu, parse_mode='HTML')

async def help_info(message: types.Message):
    """Справочная информация"""
    
    help_text = """
ℹ️ <b>СПРАВКА ПО СИСТЕМЕ</b>

<b>🎯 Основные действия:</b>
• ✅ ПРИБЫЛ - отметка о прибытии на локацию
• ❌ УБЫЛ - отметка об убытии с локации

<b>📋 Важные правила:</b>
• Нельзя выполнить одно действие дважды подряд
• Обязательно выбирать локацию из предложенных
• Все действия сохраняются в личном журнале

<b>🏢 Доступные локации:</b>
🏥 Поликлиника, ⚓️ ОБРМП, 🌆 Калининград
🛒 Магазин, 🍲 Столовая, 🏨 Госпиталь
⚙️ Хоз. Работы, 🩺 ВВК, 🏛 МФЦ
🚓 Патруль, 📝 Другое

<b>📖 Дополнительно:</b>
• Журнал - просмотр ваших записей
• Автоматические уведомления командирам
• Ежедневные сводки в 19:00

<b>🆘 Проблемы?</b>
Обратитесь к командиру или администратору системы.
    """
    
    user_id = message.from_user.id
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(help_text, reply_markup=menu, parse_mode='HTML')

async def show_registration_required(message: types.Message):
    """Показ сообщения о необходимости регистрации"""
    reg_text = """
⚠️ <b>ТРЕБУЕТСЯ РЕГИСТРАЦИЯ</b>

Для использования системы необходимо зарегистрироваться.

Используйте команду /start для начала регистрации.
    """
    await message.answer(reg_text, parse_mode='HTML')

async def handle_outdated_buttons(message: types.Message):
    """Обработка устаревших кнопок"""
    
    outdated_text = """
⚠️ <b>МЕНЮ УСТАРЕЛО</b>

Кнопки из предыдущего меню больше не действительны.

Выберите действие из актуального меню:
    """
    
    user_id = message.from_user.id
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer(outdated_text, reply_markup=menu, parse_mode='HTML')

def load_notifications():
    """Загрузка уведомлений из файла"""
    notifications_file = os.path.join(os.path.dirname(__file__), '..', 'locales', 'notifications.json')
    try:
        with open(notifications_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {"status_changes": {"arrived": ["✅ {fio} ПРИБЫЛ на {location}"], "departed": ["❌ {fio} УБЫЛ из {location}"]}}

def register_user_handlers(dp: Dispatcher):
    """Регистрация пользовательских хендлеров"""
    
    # Основные команды
    dp.register_message_handler(cmd_start, commands=['start'])
    
    # Состояния
    dp.register_message_handler(process_fio_registration, state=UserStates.waiting_for_fio)
    dp.register_message_handler(process_location_choice, state=UserStates.choosing_location)
    dp.register_message_handler(process_custom_location, state=UserStates.waiting_for_custom_location)
    
    # Действия с кнопок
    dp.register_message_handler(arrive_action, lambda m: m.text == "✅ ПРИБЫЛ")
    dp.register_message_handler(depart_action, lambda m: m.text == "❌ УБЫЛ")
    dp.register_message_handler(my_journal, lambda m: m.text == "📖 Мой журнал")
    dp.register_message_handler(help_info, lambda m: m.text == "ℹ️ Справка")
    
    # Обработка устаревших кнопок (должно быть в конце)
    dp.register_message_handler(
        handle_outdated_buttons, 
        lambda m: m.text and not m.text.startswith('/') and m.text not in [
            # Основные пользовательские кнопки
            "✅ ПРИБЫЛ", "❌ УБЫЛ", "📖 Мой журнал", "ℹ️ Справка", "👨‍💼 Админ панель",
            # Локации
            "🏥 Поликлиника", "⚓️ ОБРМП", "🌆 Калининград", "🛒 Магазин",
            "🍲 Столовая", "🏨 Госпиталь", "⚙️ Хоз. Работы", "🩺 ВВК",
            "🏛 МФЦ", "🚓 Патруль", "📝 Другое", "🔙 Отмена",
            # Админские кнопки - уровень 1
            "📊 Быстрая сводка", "👥 Управление л/с", "📖 Журнал событий", "📤 Экспорт данных", 
            "🛡️ Командиры", "⚙️ Настройки",
            # Админские кнопки - уровень 2 (Управление л/с)
            "📋 Список всех", "➕ Добавить бойца", "✏️ Изменить ФИО", "❌ Удалить бойца", 
            "📊 Статистика л/с",
            # Админские кнопки - уровень 2 (Командиры)
            "👀 Список командиров", "👑 Назначить командира", "🔔 PUSH права", 
            "📊 Права в отчётах", "❌ Убрать командира",
            # Админские кнопки - уровень 2 (Журнал событий)
            "📊 Все отметки", "📅 Отчёт за дату", "👤 Отчёт по бойцу", "📥 Экспорт данных",
            # Админские кнопки - уровень 3 (Экспорт данных)
            "📅 Вчера", "🎯 Сегодня", "📊 7 дней", "📈 30 дней", "📋 Все записи", "👥 Список бойцов",
            # Админские кнопки - уровень 3 (Настройки)
            "🔔 Уведомления", "👑 Управление админами", "⚠️ Опасная зона",
            # Админские кнопки - уровень 4 (Уведомления)
            "🔊 Вкл/выкл уведомления", "⏰ Настройка времени", "📢 Типы уведомлений", "🌙 Режим тишины",
            # Админские кнопки - уровень 4 (Управление админами)
            "👀 Список админов", "👑 Назначить админа", "❌ Убрать админа", "🔄 Сменить роль",
            # Админские кнопки - уровень 4 (Опасная зона)
            "🚨 Отметить всех прибывшими", "🗑️ Очистить журнал",
            # Подтверждения
            "✅ Да, подтверждаю", "❌ Отмена",
            # Навигация
            "🔙 Назад в меню", "🔙 Назад"
        ],
        state="*"
    )
