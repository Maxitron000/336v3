
from aiogram import types, Dispatcher
from keyboards import (
    admin_main_menu, personal_management_menu, journal_menu, export_menu,
    settings_menu, notifications_menu, admin_management_menu,
    danger_zone_menu, get_user_main_menu, get_confirmation_keyboard
)
from services.db_service import (
    get_all_logs, get_logs_by_date, get_logs_by_user, get_logs_by_period, export_logs_to_excel,
    get_all_users, change_user_fio, clear_logs, get_admins, set_admin_role, 
    toggle_admin_notify, export_users_to_excel, find_user, is_admin,
    add_new_user, delete_user, mark_all_present, get_absent_users, user_exists, get_fio,
    get_user_role
)
from config import ADMIN_ID
from utils.validators import validate_fio

# === УРОВЕНЬ 1: ГЛАВНОЕ МЕНЮ ===

async def admin_menu(message: types.Message):
    """🏠 Главное админ меню"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа к админ-панели.")
        return
    
    text = "🏠 <b>АДМИН-ПАНЕЛЬ</b>\n\n"
    text += "🎖️ Добро пожаловать в центр управления!\n"
    text += "Выберите нужный раздел:"
    
    await message.answer(text, reply_markup=admin_main_menu, parse_mode='HTML')

async def quick_summary(message: types.Message):
    """📊 Быстрая сводка - кто отсутствует"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    absent_users = get_absent_users()
    present_count = len(get_all_users()) - len(absent_users)
    
    text = "📊 <b>БЫСТРАЯ СВОДКА</b>\n\n"
    text += f"👥 Всего бойцов: {len(get_all_users())}\n"
    text += f"✅ Присутствует: {present_count}\n"
    text += f"❌ Отсутствует: {len(absent_users)}\n\n"
    
    if absent_users:
        text += "🚨 <b>Отсутствующие:</b>\n"
        for user in absent_users:
            location = user.get('last_location', 'Неизвестно')
            time = user.get('last_time', 'Неизвестно')
            text += f"• {user['fio']} → {location} ({time})\n"
    else:
        text += "🎉 Все бойцы на месте!"
    
    await message.answer(text, reply_markup=admin_main_menu, parse_mode='HTML')

# === УРОВЕНЬ 2: УПРАВЛЕНИЕ Л/С ===

async def personal_management(message: types.Message):
    """👥 Управление личным составом"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "👥 <b>УПРАВЛЕНИЕ ЛИЧНЫМ СОСТАВОМ</b>\n\n"
    text += "🔧 Здесь вы можете:\n"
    text += "• Изменить данные бойца\n"
    text += "• Добавить нового бойца\n"
    text += "• Удалить бойца из системы\n"
    text += "• Просмотреть список всех бойцов"
    
    await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')

async def show_all_users(message: types.Message):
    """📋 Список всех бойцов"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    users = get_all_users()
    if not users:
        await message.answer("👥 Нет зарегистрированных бойцов.", reply_markup=personal_management_menu)
        return

    text = "👥 <b>СПИСОК ВСЕХ БОЙЦОВ:</b>\n\n"
    for i, user in enumerate(users, 1):
        status_emoji = "✅" if user['status'] == "ПРИБЫЛ" else "❌"
        text += f"{i}. {status_emoji} {user['fio']} - {user['status']}\n"
        text += f"   🆔 ID: <code>{user['user_id']}</code>\n\n"

    await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')

# === УРОВЕНЬ 2: ЖУРНАЛ СОБЫТИЙ ===

async def journal_events(message: types.Message):
    """📖 Журнал событий"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "📖 <b>ЖУРНАЛ СОБЫТИЙ</b>\n\n"
    text += "📋 Здесь доступны:\n"
    text += "• Просмотр всех отметок\n"
    text += "• Отчёты за конкретную дату\n"
    text += "• Отчёты по конкретному бойцу\n"
    text += "• Экспорт данных в Excel"
    
    await message.answer(text, reply_markup=journal_menu, parse_mode='HTML')

async def all_visits(message: types.Message):
    """📊 Все отметки"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
        
    logs = get_all_logs()
    if not logs:
        await message.answer("📋 Журнал пуст.", reply_markup=journal_menu)
        return

    text = "📊 <b>ВСЕ ОТМЕТКИ:</b>\n\n"
    for i, log in enumerate(logs[-15:], 1):  # Показываем последние 15
        action_emoji = "✅" if log['action'] == "ПРИБЫЛ" else "❌"
        text += f"{i}. {action_emoji} {log['date']} {log['time']}\n"
        text += f"   👤 {log['fio']}\n"
        text += f"   📍 {log['location']}\n\n"

    if len(logs) > 15:
        text += f"📝 И ещё {len(logs) - 15} записей..."

    await message.answer(text, reply_markup=journal_menu, parse_mode='HTML')

async def export_data_menu(message: types.Message):
    """📥 Меню экспорта данных"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "📥 <b>ЭКСПОРТ ДАННЫХ</b>\n\n"
    text += "📊 Выберите период для экспорта:\n\n"
    text += "📅 <b>Вчера</b> - данные за вчерашний день\n"
    text += "🎯 <b>Сегодня</b> - данные за сегодня\n"
    text += "📊 <b>7 дней</b> - данные за последнюю неделю\n"
    text += "📈 <b>30 дней</b> - данные за последний месяц\n"
    text += "📋 <b>Все записи</b> - полный экспорт журнала\n"
    text += "👥 <b>Список бойцов</b> - экспорт личного состава"
    
    await message.answer(text, reply_markup=export_menu, parse_mode='HTML')

async def export_yesterday(message: types.Message):
    """📅 Экспорт за вчера"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        logs = get_logs_by_period(-1)
        if not logs:
            await message.answer("📅 Нет данных за вчера", reply_markup=export_menu)
            return
        
        file_path = export_logs_to_excel("вчера", logs)
        await message.answer_document(
            types.InputFile(file_path), 
            caption="📅 Экспорт данных за вчера", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

async def export_today(message: types.Message):
    """🎯 Экспорт за сегодня"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        logs = get_logs_by_period(0)
        if not logs:
            await message.answer("🎯 Нет данных за сегодня", reply_markup=export_menu)
            return
        
        file_path = export_logs_to_excel("сегодня", logs)
        await message.answer_document(
            types.InputFile(file_path), 
            caption="🎯 Экспорт данных за сегодня", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

async def export_7_days(message: types.Message):
    """📊 Экспорт за 7 дней"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        logs = get_logs_by_period(7)
        if not logs:
            await message.answer("📊 Нет данных за последние 7 дней", reply_markup=export_menu)
            return
        
        file_path = export_logs_to_excel("7_дней", logs)
        await message.answer_document(
            types.InputFile(file_path), 
            caption="📊 Экспорт данных за 7 дней", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

async def export_30_days(message: types.Message):
    """📈 Экспорт за 30 дней"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        logs = get_logs_by_period(30)
        if not logs:
            await message.answer("📈 Нет данных за последние 30 дней", reply_markup=export_menu)
            return
        
        file_path = export_logs_to_excel("30_дней", logs)
        await message.answer_document(
            types.InputFile(file_path), 
            caption="📈 Экспорт данных за 30 дней", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

async def export_all_logs(message: types.Message):
    """📋 Экспорт всех записей"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        file_path = export_logs_to_excel("все_записи")
        await message.answer_document(
            types.InputFile(file_path), 
            caption="📋 Экспорт всех записей журнала", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

async def export_users_list(message: types.Message):
    """👥 Экспорт списка бойцов"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        file_path = export_users_to_excel()
        await message.answer_document(
            types.InputFile(file_path), 
            caption="👥 Экспорт списка всех бойцов", 
            reply_markup=export_menu
        )
    except Exception as e:
        await message.answer(f"❌ Ошибка экспорта: {str(e)}", reply_markup=export_menu)

# === УРОВЕНЬ 2: НАСТРОЙКИ ===

async def settings_menu_handler(message: types.Message):
    """⚙️ Настройки"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "⚙️ <b>НАСТРОЙКИ СИСТЕМЫ</b>\n\n"
    text += "🔧 Доступные разделы:\n"
    text += "• 🔔 Настройка уведомлений\n"
    text += "• 👑 Управление админами\n"
    text += "• ⚠️ Опасная зона (критические действия)"
    
    await message.answer(text, reply_markup=settings_menu, parse_mode='HTML')

# === УРОВЕНЬ 3: УВЕДОМЛЕНИЯ ===

async def notifications_settings(message: types.Message):
    """🔔 Настройки уведомлений"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "🔔 <b>НАСТРОЙКИ УВЕДОМЛЕНИЙ</b>\n\n"
    text += "📢 Здесь можно:\n"
    text += "• Включить/выключить уведомления\n"
    text += "• Настроить время отправки\n"
    text += "• Выбрать типы уведомлений\n"
    text += "• Настроить режим тишины"
    
    await message.answer(text, reply_markup=notifications_menu, parse_mode='HTML')

async def toggle_notifications(message: types.Message):
    """🔊 Вкл/выкл уведомления"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    user_id = message.from_user.id
    toggle_admin_notify(user_id)
    await message.answer("🔔 Настройки уведомлений изменены!", reply_markup=notifications_menu)

async def time_settings(message: types.Message):
    """⏰ Настройка времени"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "⏰ <b>НАСТРОЙКА ВРЕМЕНИ</b>\n\n"
    text += "🕐 Текущие настройки:\n"
    text += "• Автосводка: 19:00 (Калининградское время)\n"
    text += "• Напоминания: 20:30 (Калининградское время)\n\n"
    text += "⚙️ Время настроено автоматически и работает стабильно."
    
    await message.answer(text, reply_markup=notifications_menu, parse_mode='HTML')

async def notification_types(message: types.Message):
    """📢 Типы уведомлений"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "📢 <b>ТИПЫ УВЕДОМЛЕНИЙ</b>\n\n"
    text += "Доступные типы:\n"
    text += "✅ Автосводки (19:00)\n"
    text += "✅ Напоминания о невернувшихся (20:30)\n"
    text += "✅ Системные уведомления\n"
    text += "✅ Уведомления о действиях бойцов\n\n"
    text += "🔧 Все типы включены по умолчанию."
    
    await message.answer(text, reply_markup=notifications_menu, parse_mode='HTML')

async def quiet_mode(message: types.Message):
    """🌙 Режим тишины"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "🌙 <b>РЕЖИМ ТИШИНЫ</b>\n\n"
    text += "⏰ Автоматический режим тишины:\n"
    text += "• С 22:00 до 06:00 - минимум уведомлений\n"
    text += "• Критические уведомления всегда проходят\n"
    text += "• Автосводки и напоминания работают по расписанию\n\n"
    text += "🛠️ Режим настроен автоматически."
    
    await message.answer(text, reply_markup=notifications_menu, parse_mode='HTML')

# === УРОВЕНЬ 3: УПРАВЛЕНИЕ АДМИНАМИ ===

async def admin_management_handler(message: types.Message):
    """👑 Управление админами"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "👑 <b>УПРАВЛЕНИЕ АДМИНАМИ</b>\n\n"
    text += "🎖️ Здесь можно:\n"
    text += "• Просмотреть список админов\n"
    text += "• Назначить нового админа\n"
    text += "• Убрать права админа\n"
    text += "• Изменить роль админа"
    
    await message.answer(text, reply_markup=admin_management_menu, parse_mode='HTML')

async def show_admins(message: types.Message):
    """👀 Список админов"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
        
    admins = get_admins()
    text = "👑 <b>СПИСОК АДМИНОВ:</b>\n\n"
    
    # Добавляем себя в список если является админом
    current_user_id = message.from_user.id
    current_user_in_list = any(admin['user_id'] == current_user_id for admin in admins)
    
    if not current_user_in_list and is_admin(current_user_id):
        current_fio = get_fio(current_user_id) or "Текущий админ"
        current_role = get_user_role(current_user_id)
        admins.insert(0, {
            'user_id': current_user_id,
            'fio': current_fio,
            'role': current_role,
            'notify': True
        })
    
    for i, admin in enumerate(admins, 1):
        role_emoji = "👑" if admin.get('role') == 'main' else "👨‍💼"
        notify_status = "🔔" if admin.get('notify', True) else "🔕"
        text += f"{i}. {role_emoji} {admin['fio']} {notify_status}\n"
        text += f"   ID: {admin['user_id']}\n\n"
    
    await message.answer(text, reply_markup=admin_management_menu, parse_mode='HTML')

async def assign_admin(message: types.Message):
    """👑 Назначить админа"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    await show_users_for_admin_assignment(message, page=1)

async def remove_admin(message: types.Message):
    """❌ Убрать админа"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    await show_admins_for_removal(message, page=1)

async def change_role(message: types.Message):
    """🔄 Сменить роль"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "🔄 <b>СМЕНА РОЛИ</b>\n\n"
    text += "👑 Доступные роли:\n"
    text += "• Главный админ - полный доступ\n"
    text += "• Обычный админ - ограниченный доступ\n"
    text += "• Обычный пользователь - только базовые функции\n\n"
    text += "📝 Введите ID и новую роль"
    
    await message.answer(text, reply_markup=admin_management_menu, parse_mode='HTML')

# === УРОВЕНЬ 3: ОПАСНАЯ ЗОНА ===

async def danger_zone_handler(message: types.Message):
    """⚠️ Опасная зона"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "⚠️ <b>ОПАСНАЯ ЗОНА</b>\n\n"
    text += "🚨 <b>ВНИМАНИЕ!</b> Здесь находятся критические действия:\n\n"
    text += "• 🚨 Отметить всех прибывшими\n"
    text += "• 🗑️ Очистить весь журнал\n\n"
    text += "⚡ Все действия требуют подтверждения!"
    
    await message.answer(text, reply_markup=danger_zone_menu, parse_mode='HTML')

async def mark_all_present_request(message: types.Message):
    """🚨 Запрос на отметку всех прибывшими"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "🚨 <b>КРИТИЧЕСКОЕ ДЕЙСТВИЕ</b>\n\n"
    text += "⚠️ Вы действительно хотите отметить ВСЕХ бойцов как ПРИБЫВШИХ?\n\n"
    text += "🔥 Это действие нельзя отменить!\n"
    text += "📝 Будет создана запись в журнале для каждого бойца."
    
    await message.answer(text, reply_markup=get_confirmation_keyboard(), parse_mode='HTML')

async def clear_journal_request(message: types.Message):
    """🗑️ Запрос на очистку журнала"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "🗑️ <b>КРИТИЧЕСКОЕ ДЕЙСТВИЕ</b>\n\n"
    text += "⚠️ Вы действительно хотите ПОЛНОСТЬЮ ОЧИСТИТЬ журнал?\n\n"
    text += "💥 ВСЕ ДАННЫЕ БУДУТ УДАЛЕНЫ НАВСЕГДА!\n"
    text += "📋 Это действие нельзя отменить!"
    
    await message.answer(text, reply_markup=get_confirmation_keyboard(), parse_mode='HTML')

# === ОБРАБОТЧИКИ ПОДТВЕРЖДЕНИЙ ===

async def confirm_mark_all_present(message: types.Message):
    """Подтверждение отметки всех прибывшими"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    try:
        count = mark_all_present()
        text = f"✅ <b>ВЫПОЛНЕНО!</b>\n\n"
        text += f"🎖️ Отмечено прибывшими: {count} бойцов\n"
        text += f"⏰ Время операции: {message.date.strftime('%H:%M:%S')}"
        
        await message.answer(text, reply_markup=danger_zone_menu, parse_mode='HTML')
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=danger_zone_menu)

async def confirm_clear_journal(message: types.Message):
    """Подтверждение очистки журнала"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    try:
        clear_logs()
        text = "💥 <b>ЖУРНАЛ ОЧИЩЕН!</b>\n\n"
        text += "🗑️ Все записи удалены\n"
        text += "📋 Система готова к новым отметкам"
        
        await message.answer(text, reply_markup=danger_zone_menu, parse_mode='HTML')
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=danger_zone_menu)

# === УПРАВЛЕНИЕ ЛИЧНЫМ СОСТАВОМ - ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ ===

async def change_fio_request(message: types.Message):
    """✏️ Запрос на смену ФИО бойца"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "✏️ <b>СМЕНА ФИО БОЙЦА</b>\n\n"
    text += "📝 Введите ID пользователя или текущее ФИО бойца\n"
    text += "Пример: 123456789 или Иванов И.И.\n\n"
    text += "⚡ После ввода ID/ФИО вы сможете указать новое ФИО"
    
    await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')

async def add_new_fighter_request(message: types.Message):
    """➕ Запрос на добавление нового бойца"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "➕ <b>ДОБАВЛЕНИЕ НОВОГО БОЙЦА</b>\n\n"
    text += "📝 Введите данные в формате:\n"
    text += "<code>ID ФИО</code>\n\n"
    text += "Пример: <code>123456789 Петров П.П.</code>\n\n"
    text += "⚠️ ID должен быть уникальным Telegram ID пользователя"
    
    await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')

async def delete_fighter_request(message: types.Message):
    """❌ Запрос на удаление бойца"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "❌ <b>УДАЛЕНИЕ БОЙЦА</b>\n\n"
    text += "📝 Введите ID пользователя или ФИО для удаления:\n"
    text += "Пример: 123456789 или Иванов И.И.\n\n"
    text += "⚠️ <b>ВНИМАНИЕ!</b> Это действие удалит:\n"
    text += "• Данные бойца из системы\n"
    text += "• Все его записи в журнале\n\n"
    text += "🔥 Действие нельзя отменить!"
    
    await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')

async def process_fio_change(message: types.Message):
    """Обработка смены ФИО"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        parts = message.text.strip().split(' ', 1)
        if len(parts) != 2:
            await message.answer("❌ Неверный формат. Используйте: ID новое_ФИО", 
                               reply_markup=personal_management_menu)
            return
        
        user_id, new_fio = parts[0], parts[1]
        
        if not user_id.isdigit():
            await message.answer("❌ ID должен быть числом", reply_markup=personal_management_menu)
            return
            
        if not validate_fio(new_fio):
            await message.answer("❌ ФИО должно содержать минимум 2 слова и только буквы", 
                               reply_markup=personal_management_menu)
            return
        
        user_id = int(user_id)
        if not user_exists(user_id):
            await message.answer("❌ Боец с таким ID не найден", reply_markup=personal_management_menu)
            return
            
        old_fio = get_fio(user_id)
        change_user_fio(user_id, new_fio)
        
        text = f"✅ <b>ФИО ИЗМЕНЕНО!</b>\n\n"
        text += f"👤 Было: {old_fio}\n"
        text += f"👤 Стало: {new_fio}\n"
        text += f"🆔 ID: {user_id}"
        
        await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=personal_management_menu)

async def process_new_fighter(message: types.Message):
    """Обработка добавления нового бойца"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        parts = message.text.strip().split(' ', 1)
        if len(parts) != 2:
            await message.answer("❌ Неверный формат. Используйте: ID ФИО", 
                               reply_markup=personal_management_menu)
            return
        
        user_id, fio = parts[0], parts[1]
        
        if not user_id.isdigit():
            await message.answer("❌ ID должен быть числом", reply_markup=personal_management_menu)
            return
            
        if not validate_fio(fio):
            await message.answer("❌ ФИО должно содержать минимум 2 слова и только буквы", 
                               reply_markup=personal_management_menu)
            return
        
        user_id = int(user_id)
        if user_exists(user_id):
            await message.answer("❌ Боец с таким ID уже существует", reply_markup=personal_management_menu)
            return
            
        add_new_user(user_id, fio)
        
        text = f"✅ <b>БОЕЦ ДОБАВЛЕН!</b>\n\n"
        text += f"👤 ФИО: {fio}\n"
        text += f"🆔 ID: {user_id}\n"
        text += f"📍 Статус: УБЫЛ"
        
        await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=personal_management_menu)

async def process_delete_fighter(message: types.Message):
    """Обработка удаления бойца"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        user_input = message.text.strip()
        
        # Ищем пользователя по ID или ФИО
        user = find_user(user_input)
        if not user:
            await message.answer("❌ Боец не найден", reply_markup=personal_management_menu)
            return
            
        user_id, fio = user['user_id'], user['fio']
        delete_user(user_id)
        
        text = f"💥 <b>БОЕЦ УДАЛЕН!</b>\n\n"
        text += f"👤 ФИО: {fio}\n"
        text += f"🆔 ID: {user_id}\n\n"
        text += f"🗑️ Удалены все записи и данные"
        
        await message.answer(text, reply_markup=personal_management_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=personal_management_menu)

async def report_by_user(message: types.Message):
    """👤 Отчёт по бойцу"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    
    text = "👤 <b>ОТЧЁТ ПО БОЙЦУ</b>\n\n"
    text += "📝 Введите ФИО бойца или его ID для получения отчёта:\n"
    text += "Пример: Иванов И.И. или 123456789\n\n"
    text += "📊 Будет показана вся история передвижений бойца"
    
    await message.answer(text, reply_markup=journal_menu, parse_mode='HTML')

async def process_user_report(message: types.Message):
    """Обработка запроса отчёта по пользователю"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        user_input = message.text.strip()
        
        # Ищем пользователя по ID или ФИО
        user = find_user(user_input)
        if not user:
            await message.answer("❌ Боец не найден", reply_markup=journal_menu)
            return
            
        user_id, fio = user['user_id'], user['fio']
        logs = get_logs_by_user(user_id)
        
        if not logs:
            await message.answer(f"📋 У бойца {fio} нет отметок в журнале", reply_markup=journal_menu)
            return

        text = f"👤 <b>ОТЧЁТ ПО БОЙЦУ: {fio}</b>\n\n"
        for i, log in enumerate(logs[-10:], 1):  # Показываем последние 10
            action_emoji = "✅" if log['action'] == "ПРИБЫЛ" else "❌"
            text += f"{i}. {action_emoji} {log['date']} {log['time']}\n"
            text += f"   📍 {log['location']}\n\n"

        if len(logs) > 10:
            text += f"📝 И ещё {len(logs) - 10} записей..."

        await message.answer(text, reply_markup=journal_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=journal_menu)

async def show_users_for_admin_assignment(message: types.Message, page: int = 1):
    """Показать пользователей для назначения админом"""
    users = get_all_users()
    admins = get_admins()
    admin_ids = {admin['user_id'] for admin in admins}
    current_user_id = message.from_user.id
    
    # Фильтруем только не-админов и исключаем текущего пользователя
    non_admin_users = [user for user in users 
                      if user['user_id'] not in admin_ids 
                      and user['user_id'] != current_user_id]
    
    if not non_admin_users:
        await message.answer("👑 Все пользователи уже являются админами", reply_markup=admin_management_menu)
        return
    
    users_per_page = 5
    total_pages = (len(non_admin_users) + users_per_page - 1) // users_per_page
    start_idx = (page - 1) * users_per_page
    end_idx = start_idx + users_per_page
    current_users = non_admin_users[start_idx:end_idx]
    
    text = f"👑 <b>ВЫБЕРИТЕ БОЙЦА ДЛЯ НАЗНАЧЕНИЯ АДМИНОМ</b>\n"
    text += f"📄 Страница {page} из {total_pages}\n\n"
    
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    keyboard = InlineKeyboardMarkup(row_width=1)
    
    for user in current_users:
        status_emoji = "✅" if user['status'] == "ПРИБЫЛ" else "❌"
        button_text = f"{status_emoji} {user['fio']}"
        keyboard.add(InlineKeyboardButton(
            button_text, 
            callback_data=f"assign_admin_{user['user_id']}"
        ))
    
    # Кнопки навигации
    nav_buttons = []
    if page > 1:
        nav_buttons.append(InlineKeyboardButton("⬅️ Назад", callback_data=f"admin_page_{page-1}"))
    if page < total_pages:
        nav_buttons.append(InlineKeyboardButton("Вперед ➡️", callback_data=f"admin_page_{page+1}"))
    
    if nav_buttons:
        keyboard.row(*nav_buttons)
    
    keyboard.add(InlineKeyboardButton("🔙 Отмена", callback_data="cancel_admin_assignment"))
    
    await message.answer(text, reply_markup=keyboard, parse_mode='HTML')

async def show_admins_for_removal(message: types.Message, page: int = 1):
    """Показать админов для удаления"""
    admins = get_admins()
    current_user_id = message.from_user.id
    
    # Фильтруем админов (нельзя удалить себя и главного админа)
    removable_admins = [admin for admin in admins 
                       if admin['user_id'] != current_user_id 
                       and admin.get('role') != 'main']
    
    if not removable_admins:
        await message.answer("❌ Нет админов, которых можно удалить", reply_markup=admin_management_menu)
        return
    
    admins_per_page = 5
    total_pages = (len(removable_admins) + admins_per_page - 1) // admins_per_page
    start_idx = (page - 1) * admins_per_page
    end_idx = start_idx + admins_per_page
    current_admins = removable_admins[start_idx:end_idx]
    
    text = f"❌ <b>ВЫБЕРИТЕ АДМИНА ДЛЯ УДАЛЕНИЯ</b>\n"
    text += f"📄 Страница {page} из {total_pages}\n\n"
    
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    keyboard = InlineKeyboardMarkup(row_width=1)
    
    for admin in current_admins:
        role_emoji = "👨‍💼" if admin.get('role') == 'admin' else "👑"
        button_text = f"{role_emoji} {admin['fio']}"
        keyboard.add(InlineKeyboardButton(
            button_text, 
            callback_data=f"remove_admin_{admin['user_id']}"
        ))
    
    # Кнопки навигации
    nav_buttons = []
    if page > 1:
        nav_buttons.append(InlineKeyboardButton("⬅️ Назад", callback_data=f"remove_page_{page-1}"))
    if page < total_pages:
        nav_buttons.append(InlineKeyboardButton("Вперед ➡️", callback_data=f"remove_page_{page+1}"))
    
    if nav_buttons:
        keyboard.row(*nav_buttons)
    
    keyboard.add(InlineKeyboardButton("🔙 Отмена", callback_data="cancel_admin_removal"))
    
    await message.answer(text, reply_markup=keyboard, parse_mode='HTML')

async def process_admin_assignment_callback(callback_query: types.CallbackQuery):
    """Обработка назначения админа через callback"""
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer("❌ Нет доступа")
        return
    
    user_id = int(callback_query.data.split('_')[2])
    user = find_user(str(user_id))
    
    if not user:
        await callback_query.answer("❌ Пользователь не найден")
        return
    
    # Назначаем обычного админа
    set_admin_role(user_id, 'admin')
    
    text = f"👑 <b>АДМИН НАЗНАЧЕН!</b>\n\n"
    text += f"👤 ФИО: {user['fio']}\n"
    text += f"🆔 ID: {user_id}\n"
    text += f"🎖️ Роль: Обычный админ"
    
    await callback_query.message.edit_text(text, parse_mode='HTML')
    await callback_query.message.answer("Возвращаемся в меню управления админами", reply_markup=admin_management_menu)
    await callback_query.answer("✅ Админ назначен!")

async def process_admin_removal_callback(callback_query: types.CallbackQuery):
    """Обработка удаления админа через callback"""
    if not is_admin(callback_query.from_user.id):
        await callback_query.answer("❌ Нет доступа")
        return
    
    user_id = int(callback_query.data.split('_')[2])
    user = find_user(str(user_id))
    
    if not user:
        await callback_query.answer("❌ Пользователь не найден")
        return
    
    # Убираем права админа
    set_admin_role(user_id, 'user')
    
    text = f"❌ <b>ПРАВА АДМИНА УДАЛЕНЫ!</b>\n\n"
    text += f"👤 ФИО: {user['fio']}\n"
    text += f"🆔 ID: {user_id}\n"
    text += f"👤 Новая роль: Обычный пользователь"
    
    await callback_query.message.edit_text(text, parse_mode='HTML')
    await callback_query.message.answer("Возвращаемся в меню управления админами", reply_markup=admin_management_menu)
    await callback_query.answer("✅ Права админа удалены!")

async def handle_admin_pagination(callback_query: types.CallbackQuery):
    """Обработка пагинации для назначения админов"""
    page = int(callback_query.data.split('_')[2])
    await callback_query.message.delete()
    await show_users_for_admin_assignment(callback_query.message, page)
    await callback_query.answer()

async def handle_remove_pagination(callback_query: types.CallbackQuery):
    """Обработка пагинации для удаления админов"""
    page = int(callback_query.data.split('_')[2])
    await callback_query.message.delete()
    await show_admins_for_removal(callback_query.message, page)
    await callback_query.answer()

async def cancel_admin_actions(callback_query: types.CallbackQuery):
    """Отмена действий с админами"""
    await callback_query.message.delete()
    await callback_query.message.answer("❌ Действие отменено", reply_markup=admin_management_menu)
    await callback_query.answer()

async def process_admin_removal(message: types.Message):
    """Обработка удаления админа"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        user_input = message.text.strip()
        
        if not user_input.isdigit():
            await message.answer("❌ Введите только ID пользователя", reply_markup=admin_management_menu)
            return
            
        user_id = int(user_input)
        user = find_user(user_input)
        if not user:
            await message.answer("❌ Пользователь не найден", reply_markup=admin_management_menu)
            return
        
        # Убираем права админа
        set_admin_role(user_id, 'user')
        
        text = f"❌ <b>ПРАВА АДМИНА УДАЛЕНЫ!</b>\n\n"
        text += f"👤 ФИО: {user['fio']}\n"
        text += f"🆔 ID: {user_id}\n"
        text += f"👤 Новая роль: Обычный пользователь"
        
        await message.answer(text, reply_markup=admin_management_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=admin_management_menu)

async def process_role_change(message: types.Message):
    """Обработка смены роли"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    try:
        parts = message.text.strip().split(' ', 1)
        if len(parts) != 2:
            await message.answer("❌ Неверный формат. Используйте: ID роль", reply_markup=admin_management_menu)
            return
        
        user_input, role = parts[0], parts[1].lower()
        
        if not user_input.isdigit():
            await message.answer("❌ ID должен быть числом", reply_markup=admin_management_menu)
            return
            
        if role not in ['main', 'admin', 'user']:
            await message.answer("❌ Доступные роли: main, admin, user", reply_markup=admin_management_menu)
            return
            
        user_id = int(user_input)
        user = find_user(user_input)
        if not user:
            await message.answer("❌ Пользователь не найден", reply_markup=admin_management_menu)
            return
        
        set_admin_role(user_id, role)
        
        role_names = {
            'main': 'Главный админ',
            'admin': 'Обычный админ', 
            'user': 'Обычный пользователь'
        }
        
        text = f"🔄 <b>РОЛЬ ИЗМЕНЕНА!</b>\n\n"
        text += f"👤 ФИО: {user['fio']}\n"
        text += f"🆔 ID: {user_id}\n"
        text += f"🎖️ Новая роль: {role_names[role]}"
        
        await message.answer(text, reply_markup=admin_management_menu, parse_mode='HTML')
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}", reply_markup=admin_management_menu)

async def cancel_action(message: types.Message):
    """Отмена действия"""
    await message.answer("❌ Действие отменено", reply_markup=danger_zone_menu)

# === НАВИГАЦИЯ ===

async def back_to_main(message: types.Message):
    """🔙 Возврат в главное меню пользователя"""
    user_id = message.from_user.id
    menu = get_user_main_menu(is_admin(user_id))
    await message.answer("🏠 Главное меню:", reply_markup=menu)

async def back_to_admin_main(message: types.Message):
    """🔙 Возврат в главное админ меню"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    await admin_menu(message)

# === ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ ===

async def report_by_date(message: types.Message):
    """📅 Отчёт за дату"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return
    await message.answer("📅 Введите дату для отчёта (ДД.ММ.ГГГГ):", reply_markup=journal_menu)

async def process_date_input(message: types.Message):
    """Обработка ввода даты"""
    if not is_admin(message.from_user.id):
        await message.answer("❌ Нет доступа.")
        return

    date = message.text.strip()
    logs = get_logs_by_date(date)

    if not logs:
        await message.answer(f"📅 Нет отметок за {date}.", reply_markup=journal_menu)
        return

    text = f"📅 <b>ОТЧЁТ ЗА {date}:</b>\n\n"
    for i, log in enumerate(logs, 1):
        action_emoji = "✅" if log['action'] == "ПРИБЫЛ" else "❌"
        text += f"{i}. {action_emoji} {log['time']} | {log['fio']}\n"
        text += f"   📍 {log['location']}\n\n"

    await message.answer(text, reply_markup=journal_menu, parse_mode='HTML')

def register_admin_handlers(dp: Dispatcher):
    """Регистрация всех админских хендлеров"""
    
    # Callback handlers для интерактивного управления админами
    dp.register_callback_query_handler(process_admin_assignment_callback, lambda c: c.data.startswith('assign_admin_'))
    dp.register_callback_query_handler(process_admin_removal_callback, lambda c: c.data.startswith('remove_admin_'))
    dp.register_callback_query_handler(handle_admin_pagination, lambda c: c.data.startswith('admin_page_'))
    dp.register_callback_query_handler(handle_remove_pagination, lambda c: c.data.startswith('remove_page_'))
    dp.register_callback_query_handler(cancel_admin_actions, lambda c: c.data in ['cancel_admin_assignment', 'cancel_admin_removal'])
    
    # Уровень 1: Главное меню
    dp.register_message_handler(admin_menu, lambda m: m.text == "👨‍💼 Админ панель")
    dp.register_message_handler(quick_summary, lambda m: m.text == "📊 Быстрая сводка")
    dp.register_message_handler(personal_management, lambda m: m.text == "👥 Управление л/с")
    dp.register_message_handler(journal_events, lambda m: m.text == "📖 Журнал событий")
    dp.register_message_handler(settings_menu_handler, lambda m: m.text == "⚙️ Настройки")
    
    # Уровень 2: Управление л/с
    dp.register_message_handler(show_all_users, lambda m: m.text == "📋 Список всех бойцов")
    dp.register_message_handler(change_fio_request, lambda m: m.text == "✏️ Сменить ФИО бойца")
    dp.register_message_handler(add_new_fighter_request, lambda m: m.text == "➕ Добавить нового бойца")
    dp.register_message_handler(delete_fighter_request, lambda m: m.text == "❌ Удалить бойца")
    
    # Уровень 2: Журнал событий
    dp.register_message_handler(all_visits, lambda m: m.text == "📊 Все отметки")
    dp.register_message_handler(report_by_date, lambda m: m.text == "📅 Отчёт за дату")
    dp.register_message_handler(report_by_user, lambda m: m.text == "👤 Отчёт по бойцу")
    dp.register_message_handler(export_data_menu, lambda m: m.text == "📥 Экспорт данных")
    
    # Уровень 3: Экспорт данных
    dp.register_message_handler(export_yesterday, lambda m: m.text == "📅 Вчера")
    dp.register_message_handler(export_today, lambda m: m.text == "🎯 Сегодня")
    dp.register_message_handler(export_7_days, lambda m: m.text == "📊 7 дней")
    dp.register_message_handler(export_30_days, lambda m: m.text == "📈 30 дней")
    dp.register_message_handler(export_all_logs, lambda m: m.text == "📋 Все записи")
    dp.register_message_handler(export_users_list, lambda m: m.text == "👥 Список бойцов")
    
    # Уровень 3: Настройки
    dp.register_message_handler(notifications_settings, lambda m: m.text == "🔔 Уведомления")
    dp.register_message_handler(admin_management_handler, lambda m: m.text == "👑 Управление админами")
    dp.register_message_handler(danger_zone_handler, lambda m: m.text == "⚠️ Опасная зона")
    
    # Уровень 3: Уведомления
    dp.register_message_handler(toggle_notifications, lambda m: m.text == "🔊 Вкл/выкл уведомления")
    dp.register_message_handler(time_settings, lambda m: m.text == "⏰ Настройка времени")
    dp.register_message_handler(notification_types, lambda m: m.text == "📢 Типы уведомлений")
    dp.register_message_handler(quiet_mode, lambda m: m.text == "🌙 Режим тишины")
    
    # Уровень 3: Управление админами
    dp.register_message_handler(show_admins, lambda m: m.text == "👀 Список админов")
    dp.register_message_handler(assign_admin, lambda m: m.text == "👑 Назначить админа")
    dp.register_message_handler(remove_admin, lambda m: m.text == "❌ Убрать админа")
    dp.register_message_handler(change_role, lambda m: m.text == "🔄 Сменить роль")
    
    # Уровень 3: Опасная зона
    dp.register_message_handler(mark_all_present_request, lambda m: m.text == "🚨 Отметить всех прибывшими")
    dp.register_message_handler(clear_journal_request, lambda m: m.text == "🗑️ Очистить журнал")
    
    # Подтверждения
    dp.register_message_handler(confirm_mark_all_present, lambda m: m.text == "✅ Да, подтверждаю")
    dp.register_message_handler(confirm_clear_journal, lambda m: m.text == "✅ Да, подтверждаю")
    dp.register_message_handler(cancel_action, lambda m: m.text == "❌ Отмена")
    
    # Навигация
    dp.register_message_handler(back_to_main, lambda m: m.text == "🔙 Назад в меню")
    dp.register_message_handler(back_to_admin_main, lambda m: m.text == "🔙 Назад")
    
    # Обработка ввода данных (должны быть в конце)
    dp.register_message_handler(process_date_input, 
                               lambda m: len(m.text.split('.')) == 3 and m.text.replace('.', '').isdigit() and is_admin(m.from_user.id))
    dp.register_message_handler(process_user_report, 
                               lambda m: (m.text.isdigit() or len(m.text.split()) >= 2) and not m.text.startswith('/') and is_admin(m.from_user.id) and m.text not in ['✅ Да, подтверждаю', '❌ Отмена'])
    dp.register_message_handler(process_role_change, 
                               lambda m: len(m.text.split(' ', 1)) == 2 and m.text.split(' ', 1)[0].isdigit() and is_admin(m.from_user.id) and not m.text.startswith('/'))
    dp.register_message_handler(process_fio_change, 
                               lambda m: len(m.text.split(' ', 1)) == 2 and m.text.split(' ', 1)[0].isdigit() and is_admin(m.from_user.id) and not m.text.startswith('/'))
    dp.register_message_handler(process_new_fighter, 
                               lambda m: len(m.text.split(' ', 1)) == 2 and m.text.split(' ', 1)[0].isdigit() and is_admin(m.from_user.id) and not m.text.startswith('/'))
    dp.register_message_handler(process_delete_fighter, 
                               lambda m: (m.text.isdigit() or len(m.text.split()) >= 2) and not m.text.startswith('/') and is_admin(m.from_user.id) and m.text not in ['✅ Да, подтверждаю', '❌ Отмена'])
