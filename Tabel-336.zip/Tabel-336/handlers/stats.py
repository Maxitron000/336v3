from aiogram import Dispatcher

# Статистические отчёты, если нужно отдельное меню статистики или быстрые кнопки для админа.
# Пример — сколько раз за неделю кто убывал/прибывал и т.д.

def register_stats_handlers(dp: Dispatcher):
    pass
