import time
import threading

# Демонстрационный мониторинг для Replit (или локально)
def start_monitoring(bot, admin_id):
    def monitor():
        last_ping = time.time()
        while True:
            # Можно добавить проверку состояния (например, обмен с БД, доступность сети и т.д.)
            if time.time() - last_ping > 3600:
                bot.send_message(admin_id, "⚠️ Бот давно не отвечал! Перезапустите или проверьте состояние.")
                last_ping = time.time()
            time.sleep(600)
    thread = threading.Thread(target=monitor, daemon=True)
    thread.start()
